"""Sync configs, resourcepacks, and shaderpacks from the GitHub repo.

Uses the Git Trees API to enumerate files under modpack/configs/,
modpack/resourcepacks/, and modpack/shaderpacks/, then downloads
each file to the corresponding local .minecraft subdirectory.

Mapping (GitHub -> local .minecraft):
  modpack/configs/        ->  config/        (singular — standard Forge)
  modpack/resourcepacks/  ->  resourcepacks/
  modpack/shaderpacks/    ->  shaderpacks/
"""

import json
import urllib.request
from pathlib import Path

try:
    from utils.logger import get_logger
    logger = get_logger()
except ImportError:
    import logging
    logger = logging.getLogger("file_sync")

GITHUB_RAW_BASE = "https://raw.githubusercontent.com/trhtkfvi/Play-Launcher/main"
GITHUB_API_BASE = "https://api.github.com/repos/trhtkfvi/Play-Launcher"

# (github_prefix, local_subdir)
SYNC_MAPPINGS = [
    ("modpack/configs/", "config"),
    ("modpack/resourcepacks/", "resourcepacks"),
    ("modpack/shaderpacks/", "shaderpacks"),
]

# Placeholder files to skip
SKIP_FILES = {"resourcepacks here", "shaderpacks here"}


def sync_extra_files(instance_dir: str, progress_callback=None) -> dict:
    """Download configs, resourcepacks, and shaderpacks from GitHub.

    Args:
        instance_dir: Path to the .minecraft directory.
        progress_callback: Optional callback(current, total, message).

    Returns:
        {'downloaded': int, 'skipped': int, 'failed': int}
    """
    instance_path = Path(instance_dir)
    summary = {"downloaded": 0, "skipped": 0, "failed": 0}

    # Ensure target directories exist (even if GitHub folders are currently empty)
    for _, local_subdir in SYNC_MAPPINGS:
        (instance_path / local_subdir).mkdir(parents=True, exist_ok=True)

    # --- Fetch the full repo tree ---
    try:
        req = urllib.request.Request(
            f"{GITHUB_API_BASE}/git/trees/main?recursive=1",
            headers={
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/vnd.github+json",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            tree_data = json.loads(response.read().decode())
    except Exception as ex:
        logger.error(f"[FILE SYNC] Failed to fetch GitHub tree: {ex}")
        summary["failed"] = -1
        if progress_callback:
            progress_callback(0, 0, "Failed to fetch file list from GitHub")
        return summary

    # --- Filter for files in our sync directories ---
    files_to_download = []
    for item in tree_data.get("tree", []):
        if item.get("type") != "blob":
            continue
        path = item.get("path", "")
        for github_prefix, local_subdir in SYNC_MAPPINGS:
            if path.startswith(github_prefix):
                filename = Path(path).name
                if filename in SKIP_FILES:
                    continue
                relative = path[len(github_prefix):]
                local_path = instance_path / local_subdir / relative
                files_to_download.append((path, local_path))
                break

    total = len(files_to_download)
    if total == 0:
        if progress_callback:
            progress_callback(0, 0, "No extra files to sync")
        return summary

    # --- Download each file ---
    for idx, (github_path, local_path) in enumerate(files_to_download, 1):
        filename = Path(github_path).name

        try:
            local_path.parent.mkdir(parents=True, exist_ok=True)
            url = f"{GITHUB_RAW_BASE}/{github_path}"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as response:
                local_path.write_bytes(response.read())
            summary["downloaded"] += 1
            if progress_callback:
                progress_callback(idx, total, f"Synced {filename}")
        except Exception as ex:
            logger.warning(f"[FILE SYNC] Failed to download {github_path}: {ex}")
            summary["failed"] += 1
            if progress_callback:
                progress_callback(idx, total, f"Failed: {filename}")

    return summary
