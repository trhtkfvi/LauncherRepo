"""
Single source of truth for resolving the user's home directory and the
Minecraft instance directory.

Why this exists: Python's Path.home() (== os.path.expanduser("~")) honors
the HOME environment variable on Windows if it happens to be set - which
happens automatically inside Git Bash / MSYS2 / some IDE terminals, and
those tools set HOME to a POSIX-style path like C:\\home\\<user> instead of
the real Windows profile folder (C:\\Users\\<user>). If the app is launched
from a shell that sets HOME, the instance directory silently resolves to
the wrong place, so mods get downloaded to one location while the game
launches from another. On real Windows without one of those shells,
Path.home() just uses USERPROFILE, so this is safe everywhere and only
changes behavior in the exact case that was causing the bug.
"""

import os
import platform
from pathlib import Path


def get_user_home() -> Path:
    """Resolves the correct OS user home directory, Windows-safe."""
    if platform.system() == "Windows":
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            return Path(userprofile)

        homedrive = os.environ.get("HOMEDRIVE")
        homepath = os.environ.get("HOMEPATH")
        if homedrive and homepath:
            return Path(homedrive + homepath)

    return Path.home()


def get_minecraft_dir() -> Path:
    """Returns the canonical <user_home>/.play_launcher/.minecraft directory."""
    return get_user_home() / ".play_launcher" / ".minecraft"
