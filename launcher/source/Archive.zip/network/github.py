import requests
from typing import Dict, Any, Optional

class GitHubMetadataManager:
    def fetch_modpack_manifest(self, url: str) -> Optional[Dict[str, Any]]:
        try:
            res = requests.get(url, timeout=10)
            if res.status_code == 200:
                return res.json()
        except Exception:
            pass
        return None