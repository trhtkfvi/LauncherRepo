"""
Modpack Manifest Data Models & Schema Validator
Parses GitHub modpack manifest.json containing mod lists, hashes, optional mods, resourcepacks, and configs.
Adapted for the actual manifest field names used in the Play-Launcher repo.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Any, Optional

# Default versions used when the manifest doesn't specify them
LAUNCHER_VERSION = "1.0.0"
TARGET_MINECRAFT_VERSION = "1.20.1"
TARGET_FORGE_VERSION = "47.4.10"


@dataclass
class ModItem:
    name: str
    provider: str = ""          # "modrinth", "curseforge", or "direct"
    project_id: str = ""
    version_id: str = ""
    required: bool = True
    hash: str = ""
    hash_format: str = "sha512"  # "sha512", "sha1", or "sha256"
    download_mode: str = "url"  # "url" or "metadata:curseforge"
    url: str = ""
    filename: str = ""
    minecraft_versions: List[str] = field(default_factory=list)
    loaders: List[str] = field(default_factory=list)
    release_type: str = ""
    version_number: str = ""
    dependencies: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        if not self.filename:
            self.filename = f"{self.name.lower().replace(' ', '_')}.jar"

    @property
    def file_name(self) -> str:
        """Alias for filename for backward compatibility."""
        return self.filename


@dataclass
class ModpackManifest:
    launcher_version: str = LAUNCHER_VERSION
    minecraft_version: str = TARGET_MINECRAFT_VERSION
    forge_version: str = TARGET_FORGE_VERSION
    minimum_launcher_version: str = LAUNCHER_VERSION
    maintenance: bool = False
    mods: List[ModItem] = field(default_factory=list)
    optional_mods: List[ModItem] = field(default_factory=list)
    resource_packs: List[Dict[str, Any]] = field(default_factory=list)
    shader_packs: List[Dict[str, Any]] = field(default_factory=list)
    configs: List[Dict[str, Any]] = field(default_factory=list)

    @staticmethod
    def _remap_mod_keys(raw: Dict[str, Any]) -> Dict[str, Any]:
        """Remaps camelCase / variant JSON keys to ModItem fields and strips unknown keys."""
        _key_map = {
            "filename": "filename",
            "file_name": "filename",
            "fileName": "filename",
            "projectId": "project_id",
            "project_id": "project_id",
            "versionId": "version_id",
            "version_id": "version_id",
            "name": "name",
            "provider": "provider",
            "required": "required",
            "sha256": "hash",
            "hash": "hash",
            "hashFormat": "hash_format",
            "hash_format": "hash_format",
            "downloadMode": "download_mode",
            "download_mode": "download_mode",
            "url": "url",
            "minecraftVersions": "minecraft_versions",
            "loaders": "loaders",
            "releaseType": "release_type",
            "versionNumber": "version_number",
            "dependencies": "dependencies",
        }
        _valid_fields = {
            "name", "provider", "project_id", "version_id", "required",
            "hash", "hash_format", "download_mode", "url", "filename",
            "minecraft_versions", "loaders", "release_type", "version_number",
            "dependencies"
        }
        remapped: Dict[str, Any] = {}
        for key, value in raw.items():
            mapped = _key_map.get(key)
            if mapped and mapped not in remapped:
                remapped[mapped] = value
        # If sha256 was the source key and no hashFormat was given, default to sha256
        if "sha256" in raw and "hash_format" not in remapped and "hashFormat" not in raw and "hash_format" not in raw:
            remapped["hash_format"] = "sha256"
        return {k: v for k, v in remapped.items() if k in _valid_fields}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModpackManifest":
        """Creates ModpackManifest instance from raw dictionary."""
        mods_list = [ModItem(**cls._remap_mod_keys(m)) for m in data.get("mods", [])]
        opt_mods = [ModItem(**cls._remap_mod_keys(m)) for m in data.get("optionalMods", [])]

        return cls(
            launcher_version=data.get("launcherVersion", LAUNCHER_VERSION),
            minecraft_version=data.get("minecraftVersion", TARGET_MINECRAFT_VERSION),
            forge_version=data.get("forgeVersion", TARGET_FORGE_VERSION),
            minimum_launcher_version=data.get("minimumLauncherVersion", LAUNCHER_VERSION),
            maintenance=data.get("maintenance", False),
            mods=mods_list,
            optional_mods=opt_mods,
            resource_packs=data.get("resourcePacks", []),
            shader_packs=data.get("shaderPacks", []),
            configs=data.get("configs", [])
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serializes manifest back to dictionary format matching GitHub spec."""
        def _mod_to_dict(m: ModItem) -> Dict[str, Any]:
            return {
                "name": m.name,
                "filename": m.filename,
                "provider": m.provider,
                "projectId": m.project_id,
                "versionId": m.version_id,
                "required": m.required,
                "hash": m.hash,
                "hashFormat": m.hash_format,
                "downloadMode": m.download_mode,
                "url": m.url,
                "minecraftVersions": m.minecraft_versions,
                "loaders": m.loaders,
                "releaseType": m.release_type,
                "versionNumber": m.version_number,
                "dependencies": m.dependencies
            }
        return {
            "launcherVersion": self.launcher_version,
            "minecraftVersion": self.minecraft_version,
            "forgeVersion": self.forge_version,
            "minimumLauncherVersion": self.minimum_launcher_version,
            "maintenance": self.maintenance,
            "mods": [_mod_to_dict(m) for m in self.mods],
            "optionalMods": [_mod_to_dict(m) for m in self.optional_mods],
            "resourcePacks": self.resource_packs,
            "shaderPacks": self.shader_packs,
            "configs": self.configs
        }

    @classmethod
    def from_file(cls, path: Path) -> Optional["ModpackManifest"]:
        """Loads a manifest from a local JSON file."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls.from_dict(json.load(f))
        except Exception as e:
            return None

    def save_to_file(self, path: Path) -> bool:
        """Saves the manifest to a local JSON file."""
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.to_dict(), f, indent=4)
            return True
        except Exception:
            return False