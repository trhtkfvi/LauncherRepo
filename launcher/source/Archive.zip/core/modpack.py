"""
Modpack Management & Sync Engine
Synchronizes local mod files against GitHub manifest, verifies hashes (SHA-512 / SHA-1 / SHA-256),
manages optional mods, removes stale files, and returns a sync summary.
"""

import os
import json
import hashlib
import logging
import urllib.parse
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional, Callable
from dataclasses import dataclass, field
import requests

from core.manifest import ModpackManifest, ModItem

# Robust logger initialization with fallback
try:
    from utils.logger import logger
except ImportError:
    try:
        from utils.logger import get_logger
        logger = get_logger()
    except ImportError:
        logger = logging.getLogger("PlayLauncher")
        if not logger.handlers:
            logging.basicConfig(
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            )


@dataclass
class ModSyncSummary:
    """Tracks which mods were added, removed, and updated during a sync."""
    added: List[str] = field(default_factory=list)
    removed: List[str] = field(default_factory=list)
    updated: List[str] = field(default_factory=list)
    failed: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)

    @property
    def total_changes(self) -> int:
        return len(self.added) + len(self.removed) + len(self.updated)

    def __str__(self) -> str:
        return (
            f"SyncSummary(added={len(self.added)}, removed={len(self.removed)}, "
            f"updated={len(self.updated)}, failed={len(self.failed)}, skipped={len(self.skipped)})"
        )


class ModpackManager:
    """Synchronizes modpack files against local and remote manifests."""

    GITHUB_RAW_BASE = "https://raw.githubusercontent.com/trhtkfvi/Play-Launcher/main"

    def __init__(self, manifest_source=None, instance_dir: str = "./instance_data"):
        """
        Initializes the ModpackManager for Play Launcher.

        :param manifest_source: Can be a local path string, a URL string, a Path object,
                                or a LauncherSettings configuration object.
        :param instance_dir: Root directory for the Minecraft instance files.
        """
        if manifest_source is not None and not isinstance(manifest_source, (str, Path)):
            if hasattr(manifest_source, "manifest_path") and getattr(manifest_source, "manifest_path"):
                manifest_source = manifest_source.manifest_path
            elif hasattr(manifest_source, "manifest_url") and getattr(manifest_source, "manifest_url"):
                manifest_source = manifest_source.manifest_url
            else:
                manifest_source = None

        self.instance_dir = Path(instance_dir)
        self.manifest_source = manifest_source or f"{self.GITHUB_RAW_BASE}/modpack/manifest.json"

        # Local manifest cache for offline comparison and stale-file detection
        self.local_manifest_file = self.instance_dir / "modpack_manifest.json"

        # Load remote manifest as dataclass
        self.manifest_dict: dict = self._load_manifest()
        self.manifest: ModpackManifest = ModpackManifest.from_dict(self.manifest_dict)

        # Load local cached manifest (for detecting removed mods)
        self.local_manifest: Optional[ModpackManifest] = self._load_local_manifest()

    # ─── Manifest Loading ───────────────────────────────────────────

    def _load_manifest(self) -> dict:
        """Loads manifest from a local file path or remote GitHub raw URL."""
        try:
            source_str = str(self.manifest_source)
            if source_str.startswith("http://") or source_str.startswith("https://"):
                logger.info(f"Fetching remote manifest from: {source_str}")
                response = requests.get(source_str, timeout=15)
                response.raise_for_status()
                return response.json()
            else:
                manifest_path = Path(source_str)
                if not manifest_path.exists():
                    raise FileNotFoundError(f"Manifest not found at local path: {manifest_path}")
                with open(manifest_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load modpack manifest: {e}")
            raise

    def _load_local_manifest(self) -> Optional[ModpackManifest]:
        """Loads the locally cached manifest for offline comparison."""
        if self.local_manifest_file.exists():
            try:
                with open(self.local_manifest_file, "r", encoding="utf-8") as f:
                    return ModpackManifest.from_dict(json.load(f))
            except Exception as e:
                logger.warning(f"Could not read local manifest cache: {e}")
        return None

    def _save_local_manifest(self) -> bool:
        """Saves the current remote manifest locally for future sync comparisons."""
        try:
            self.instance_dir.mkdir(parents=True, exist_ok=True)
            self.manifest.save_to_file(self.local_manifest_file)
            self.local_manifest = self.manifest
            return True
        except Exception as e:
            logger.warning(f"Failed to save local manifest cache: {e}")
            return False

    # ─── Hash & URL Utilities ────────────────────────────────────────

    def _calculate_hash(self, file_path: Path, hash_format: str) -> str:
        """Calculates the SHA-512, SHA-1, or SHA-256 checksum of a local file."""
        hash_format = hash_format.lower()
        if hash_format == "sha512":
            hasher = hashlib.sha512()
        elif hash_format == "sha1":
            hasher = hashlib.sha1()
        else:
            hasher = hashlib.sha256()

        with open(file_path, "rb") as f:
            while chunk := f.read(8192):
                hasher.update(chunk)
        return hasher.hexdigest()

    def _verify_file_integrity(self, file_path: Path, mod: ModItem) -> bool:
        """Returns True if the local file's hash matches the manifest's expected hash."""
        if not mod.hash:
            return True  # No hash to verify; assume valid
        try:
            current_hash = self._calculate_hash(file_path, mod.hash_format)
            return current_hash.lower() == mod.hash.lower()
        except Exception as e:
            logger.warning(f"Failed to calculate hash for {mod.filename}: {e}")
            return False

    def _resolve_curseforge_url(self, mod: ModItem) -> str:
        """Constructs a CurseForge CDN download URL for mods with downloadMode 'metadata:curseforge'."""
        file_id = mod.version_id
        filename = mod.filename
        if not file_id or not filename:
            return ""
        try:
            file_id_int = int(file_id)
        except (TypeError, ValueError):
            return ""
        part1 = file_id_int // 1000
        part2 = file_id_int % 1000
        safe_filename = urllib.parse.quote(filename, safe="")
        return f"https://mediafilez.forgecdn.net/files/{part1}/{part2}/{safe_filename}"

    def _resolve_download_url(self, mod: ModItem) -> str:
        """Resolves the download URL for a mod, constructing CurseForge CDN URLs if needed."""
        if mod.url:
            return mod.url
        if mod.download_mode == "metadata:curseforge" or mod.provider == "curseforge":
            url = self._resolve_curseforge_url(mod)
            if url:
                logger.info(f"Constructed CurseForge URL for {mod.name}: {url}")
            return url
        return ""

    # ─── Progress Callback ──────────────────────────────────────────

    def _safe_callback(self, callback, current, total, status_message):
        """Safely invokes progress callback supporting both 2 and 3 parameter signatures."""
        if not callback:
            return
        try:
            callback(current, total, status_message)
        except TypeError:
            try:
                callback(current, total)
            except Exception:
                pass
        except Exception:
            pass

    # ─── Stale File Removal ─────────────────────────────────────────

    def _remove_stale_mods(self, current_filenames: set, removed_list: List[str]):
        """
        Removes mod files that were in the previous local manifest but are no longer
        in the remote manifest. Only deletes files we previously tracked — user-added
        jars are preserved.
        """
        if not self.local_manifest:
            return

        # Build set of filenames from the previous local manifest
        old_filenames = {m.filename for m in self.local_manifest.mods}
        old_filenames.update({m.filename for m in self.local_manifest.optional_mods})

        # Find files that were tracked before but aren't anymore
        stale = old_filenames - current_filenames
        if not stale:
            return

        mods_dir = self.instance_dir / "mods"
        for filename in stale:
            stale_path = mods_dir / filename
            if stale_path.exists():
                try:
                    stale_path.unlink()
                    removed_list.append(filename)
                    logger.info(f"Removed stale mod file: {filename}")
                except Exception as e:
                    logger.warning(f"Failed removing stale mod {filename}: {e}")

    # ─── Main Sync ──────────────────────────────────────────────────

    def sync_modpack(
        self,
        progress_callback: Optional[Callable] = None,
        enabled_optional_mods: Optional[List[str]] = None
    ) -> ModSyncSummary:
        """
        Synchronizes all mods listed in the manifest, verifying their hashes and
        downloading missing or mismatched files. Returns a ModSyncSummary tracking
        added, removed, updated, and failed mods.

        :param progress_callback: Optional callback(current, total, status) for UI progress.
        :param enabled_optional_mods: Optional list of optional mod names to include.
        :raises RuntimeError: If any required mod fails to download.
        """
        summary = ModSyncSummary()

        # Build the target mod list: required mods + enabled optional mods
        target_mods: List[ModItem] = list(self.manifest.mods)
        enabled_opts = enabled_optional_mods or []
        for opt in self.manifest.optional_mods:
            if opt.name in enabled_opts:
                target_mods.append(opt)

        total_mods = len(target_mods)
        logger.info(f"Starting synchronization for {total_mods} mods from manifest...")

        mods_dir = self.instance_dir / "mods"
        mods_dir.mkdir(parents=True, exist_ok=True)

        # Track filenames for stale-file detection
        current_filenames = {m.filename for m in target_mods}

        # Remove stale mods that were previously tracked
        self._remove_stale_mods(current_filenames, summary.removed)

        downloaded_count = 0

        for idx, mod in enumerate(target_mods):
            filename = mod.filename
            name = mod.name or filename
            required = mod.required

            # Resolve download URL
            url = self._resolve_download_url(mod)

            if not filename or not url:
                logger.warning(f"Skipping mod without download URL: {name}")
                summary.skipped.append(name)
                continue

            target_path = mods_dir / filename
            download_needed = False
            change_type = None

            self._safe_callback(progress_callback, idx + 1, total_mods, f"Checking {name}...")

            # Determine if download is needed
            if not target_path.exists():
                download_needed = True
                change_type = "added"
            elif mod.hash:
                if not self._verify_file_integrity(target_path, mod):
                    download_needed = True
                    change_type = "updated"

            # Download if needed
            if download_needed:
                logger.info(f"Downloading mod: {name} from {url}")
                self._safe_callback(progress_callback, idx + 1, total_mods, f"Downloading {name}...")

                try:
                    response = requests.get(url, stream=True, timeout=30)
                    response.raise_for_status()

                    with open(target_path, "wb") as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)

                    # Post-download hash verification
                    if mod.hash:
                        if not self._verify_file_integrity(target_path, mod):
                            try:
                                target_path.unlink()
                            except Exception:
                                pass
                            raise ValueError(f"Hash validation failed after download for: {name}")

                    logger.info(f"Successfully downloaded and verified: {name}")
                    downloaded_count += 1

                    if change_type == "added":
                        summary.added.append(name)
                    elif change_type == "updated":
                        summary.updated.append(name)

                except Exception as e:
                    logger.error(f"Failed to download {name}: {e}")
                    # Clean up partial download
                    if target_path.exists():
                        try:
                            target_path.unlink()
                        except Exception:
                            pass
                    summary.failed.append(name)

                    # If required mod fails, we'll raise after processing remaining mods
                    if not required:
                        logger.warning(f"Optional mod failed (continuing): {name}")
            else:
                logger.debug(f"Verified integrity: {filename}")

        # Save local manifest cache for future sync comparisons
        self._save_local_manifest()

        logger.info(
            f"Modpack sync complete: {downloaded_count} downloaded, "
            f"{len(summary.skipped)} skipped, {len(summary.failed)} failed, "
            f"{len(summary.removed)} removed. {summary}"
        )

        # Raise if any required mods failed
        required_failures = [
            name for name in summary.failed
            if any(m.name == name and m.required for m in target_mods)
        ]
        if required_failures:
            names = ", ".join(required_failures)
            raise RuntimeError(f"{len(required_failures)} required mod(s) failed to download: {names}")

        return summary

    # ─── Backward Compatibility ─────────────────────────────────────

    def verify_and_download_files(self, progress_callback=None) -> ModSyncSummary:
        """Backward compatibility alias for sync_modpack()."""
        return self.sync_modpack(progress_callback=progress_callback)

    def get_instance_metadata(self) -> dict:
        """Extracts game version and loader configuration from manifest root keys."""
        game_version = self.manifest.minecraft_version or "1.20.1"
        forge_version = self.manifest.forge_version or "47.4.10"

        return {
            "name": self.manifest_dict.get("name", "Play Launcher Instance"),
            "game_version": game_version,
            "loader": {
                "type": "forge",
                "version": forge_version
            }
        }