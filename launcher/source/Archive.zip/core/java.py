import os
import shutil
import subprocess
from pathlib import Path
import logging

try:
    from utils.logger import logger
except ImportError:
    logger = logging.getLogger("PlayLauncher")

class JavaManager:
    def resolve_java_binary(self, custom_path: str = None) -> str:
        """
        Resolves, validates, and returns a working Java executable path.
        """
        # 1. Check custom user-provided path if available
        if custom_path and str(custom_path).strip():
            custom_path_obj = Path(custom_path)
            if custom_path_obj.exists() and custom_path_obj.is_file():
                logger.info(f"Using custom Java binary: {custom_path_obj}")
                return str(custom_path_obj.resolve())

        # 2. Check system PATH via shutil.which
        system_java = shutil.which("java")
        if system_java:
            logger.info(f"Found Java in system PATH: {system_java}")
            return system_java

        # 3. Fallback common Linux/Unix/Windows locations
        common_paths = [
            "/usr/bin/java",
            "/usr/lib/jvm/default/bin/java",
            "/usr/lib/jvm/java-17-openjdk/bin/java",
            "/usr/lib/jvm/java-21-openjdk/bin/java",
        ]
        
        for p in common_paths:
            if os.path.exists(p) and os.access(p, os.X_OK):
                logger.info(f"Found Java at common path: {p}")
                return p

        raise FileNotFoundError("Could not find a valid Java runtime. Please configure a Java path in settings or install Java 17/21.")

    @staticmethod
    def launch_minecraft(
        java_path: str,
        game_dir: Path,
        natives_dir: Path,
        classpath: list[str],
        main_class: str,
        jvm_args: list[str],
        game_args: list[str]
    ) -> subprocess.Popen:
        """
        Constructs and executes the Java subprocess for Minecraft Forge.
        """
        resolved_java = JavaManager().resolve_java_binary(java_path)
        if not os.path.exists(resolved_java):
            raise FileNotFoundError(f"Java executable not found at: {resolved_java}")

        full_classpath = os.pathsep.join(str(Path(p).resolve()) for p in classpath)
        
        command = [
            resolved_java,
            *jvm_args,
            f"-Djava.library.path={str(natives_dir.resolve())}",
            "-cp", full_classpath,
            main_class,
            *game_args
        ]

        logger.info(f"Spawning Minecraft process in directory: {game_dir}")
        
        process = subprocess.Popen(
            command,
            cwd=str(game_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        return process

# Backward compatibility alias
JavaProcessManager = JavaManager