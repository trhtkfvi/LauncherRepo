"""Check GitHub releases for launcher updates.

If a newer version is found, the caller opens the release URL in the browser.
"""

import json
import urllib.request

try:
    from utils.logger import get_logger
    logger = get_logger()
except ImportError:
    import logging
    logger = logging.getLogger("updater")

GITHUB_API_BASE = "https://api.github.com/repos/trhtkfvi/Play-Launcher"
CURRENT_VERSION = "1.0.0"


def check_for_update() -> dict:
    """Check the latest GitHub release.

    Returns:
        {
            'update_available': bool,
            'latest_version': str,
            'download_url': str,   # HTML page of the release
            'release_notes': str,
        }
    """
    result = {
        "update_available": False,
        "latest_version": CURRENT_VERSION,
        "download_url": "",
        "release_notes": "",
    }

    try:
        req = urllib.request.Request(
            f"{GITHUB_API_BASE}/releases/latest",
            headers={
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/vnd.github+json",
            },
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())

        latest = (data.get("tag_name") or "").lstrip("vV")
        result["latest_version"] = latest or CURRENT_VERSION
        result["release_notes"] = data.get("body", "")

        # Prefer the first release asset's direct download URL; fall back to the release page
        assets = data.get("assets", [])
        if assets and isinstance(assets, list) and len(assets) > 0:
            result["download_url"] = assets[0].get("browser_download_url", "")
        if not result["download_url"]:
            result["download_url"] = data.get("html_url", "")

        if latest and _compare_versions(latest, CURRENT_VERSION) > 0:
            result["update_available"] = True
            logger.info(f"[UPDATER] Update available: {latest} (current {CURRENT_VERSION})")
        else:
            logger.info(f"[UPDATER] Up to date ({CURRENT_VERSION})")

    except Exception as ex:
        logger.debug(f"[UPDATER] Failed to check for updates: {ex}")

    return result


def _compare_versions(v1: str, v2: str) -> int:
    """Return >0 if v1>v2, 0 if equal, <0 if v1<v2."""
    parts1 = [int(x) for x in v1.split(".") if x.isdigit()]
    parts2 = [int(x) for x in v2.split(".") if x.isdigit()]
    for a, b in zip(parts1, parts2):
        if a != b:
            return a - b
    return len(parts1) - len(parts2)