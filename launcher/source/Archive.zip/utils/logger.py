import sys
import logging
from pathlib import Path
from config.settings import BASE_DIR

LOG_FILE = BASE_DIR / "launcher.log"


def get_logger(name: str = "PlayLauncher") -> logging.Logger:
    """Configures and returns a standard application logger."""
    logger = logging.getLogger(name)

    if logger.hasHandlers():
        return logger

    logger.setLevel(logging.INFO)

    # Formatter for console and file output
    formatter = logging.Formatter(
        fmt="[%(asctime)s] [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S"
    )

    # Console Stream Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File Handler
    try:
        file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as err:
        logger.warning(f"Failed to initialize file logging handler: {err}")

    return logger