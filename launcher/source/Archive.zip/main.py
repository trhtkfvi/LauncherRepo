import flet as ft
import threading
import psutil
import json
import urllib.request
import subprocess
import platform
import os
import webbrowser
from pathlib import Path

from config.settings import SettingsManager
from ui.i18n import LocalizationManager
from core.java import JavaManager
from core.installer import MinecraftInstaller
from core.modpack import ModpackManager
from core.launcher import MinecraftLauncher
from core.mod_icons import extract_mod_icon
from core.mod_metadata import extract_mod_metadata
from core.file_sync import sync_extra_files
from core.updater import check_for_update
from utils.logger import get_logger

logger = get_logger()

GITHUB_RAW_BASE = "https://raw.githubusercontent.com/trhtkfvi/Play-Launcher/main"
LAUNCHER_VERSION = "1.0.0"

ACCENT_COLORS = {
    "blue": ft.Colors.BLUE,
    "green": ft.Colors.GREEN,
    "orange": ft.Colors.ORANGE,
    "purple": ft.Colors.PURPLE,
    "red": ft.Colors.RED,
}


def main(page: ft.Page):
    settings_mgr = SettingsManager()
    settings = settings_mgr.get()

    current_lang = settings.language if settings.language in ("en", "he") else "en"
    i18n = LocalizationManager(current_lang)

    installer = MinecraftInstaller(instance_dir=settings.instance_dir)
    launcher = MinecraftLauncher(settings)

    game_process_running = False

    # Cached mod data for search filtering
    all_mods_data = []

    def t(key: str, default: str, **kwargs) -> str:
        res = i18n.get(key, **kwargs)
        if res and res != f"[{key}]":
            return res
        return default.format(**kwargs) if kwargs else default

    page.window.icon = "assets/icon.ico"
    page.title = t("app_title", "Play Launcher")
    page.window.width = 1000
    page.window.height = 650
    page.window.min_width = 900
    page.window.min_height = 580
    page.padding = 0
    

    def apply_theme():
        page.theme_mode = ft.ThemeMode.DARK if settings.theme_mode == "dark" else ft.ThemeMode.LIGHT
        accent = ACCENT_COLORS.get(settings.accent_color, ft.Colors.BLUE)
        try:
            page.theme = ft.Theme(color_scheme_seed=accent)
            page.dark_theme = ft.Theme(color_scheme_seed=accent)
        except TypeError:
            page.theme = ft.Theme(color_scheme=ft.ColorScheme(primary=accent))
            page.dark_theme = ft.Theme(color_scheme=ft.ColorScheme(primary=accent))

    apply_theme()
    page.rtl = i18n.is_rtl()

    status_text = ft.Text(value=t("ready", "Ready"), size=13, color=ft.Colors.GREY_400)
    progress_bar = ft.ProgressBar(value=0, width=400, height=6, color=ft.Colors.BLUE_400)
    mod_count_text = ft.Text("", size=11, color=ft.Colors.GREY_500)

    active_acc = settings.get_active_account()
    username_field = ft.TextField(
        value=active_acc.get("username", "Player"),
        label=t("username_prompt", "Username"),
        width=200, height=45
    )

    # ------------------------------------------------------------------ #
    #  PLAY / STOP
    # ------------------------------------------------------------------ #
    def set_play_state(is_running: bool):
        nonlocal game_process_running
        game_process_running = is_running
        if is_running:
            play_btn.content.controls[0].name = ft.Icons.STOP_ROUNDED
            play_btn.content.controls[1].value = t("stop_button", "Stop Game")
            play_btn.style.bgcolor = ft.Colors.RED_700
        else:
            play_btn.content.controls[0].name = ft.Icons.PLAY_ARROW_ROUNDED
            play_btn.content.controls[1].value = t("play_button", "Play")
            play_btn.style.bgcolor = ft.Colors.BLUE_700
        play_btn.disabled = False
        page.update()

    def on_play_click(e):
        nonlocal game_process_running
        if game_process_running:
            play_btn.disabled = True
            update_status(t("stopping", "Stopping process..."), 1.0)
            for proc in psutil.process_iter(['name', 'cmdline']):
                try:
                    if proc.info['cmdline'] and 'java' in proc.info['name'].lower() and 'minecraft' in ' '.join(proc.info['cmdline']).lower():
                        proc.terminate()
                except Exception:
                    pass
            return

        play_btn.disabled = True
        active = settings.get_active_account()
        active["username"] = username_field.value.strip() or "Player"
        settings_mgr.save()
        set_play_state(True)

        def _worker():
            try:
                update_status(t("resolving_java", "Resolving Java Runtime..."), 0.1)
                java_bin = JavaManager().resolve_java_binary(settings.java_path)

                update_status(t("reading_manifest", "Reading modpack manifest..."), 0.2)
                modpack_mgr = ModpackManager(instance_dir=settings.instance_dir)
                meta = modpack_mgr.get_instance_metadata()
                mc_version = meta["game_version"]
                forge_version = meta["loader"]["version"]

                update_status(t("installing_forge", f"Installing Forge {forge_version}...", version=forge_version), 0.4)
                version_id = installer.install_forge(
                    mc_version, forge_version, java_bin=java_bin, status_callback=update_status
                )

                update_status(t("updating", "Syncing Mods via manifest.json..."), 0.6)

                def _mods_progress(current, total, message):
                    if total:
                        pct = int((current / total) * 100)
                        mod_count_text.value = f"{current} / {total} ({pct}%)"
                    else:
                        mod_count_text.value = ""
                    update_status(message, 0.6 + (0.25 * current / total) if total else 0.6)

                modpack_mgr.sync_modpack(progress_callback=_mods_progress)

                # --- Sync configs, resourcepacks, shaderpacks ---
                update_status(t("syncing_extras", "Syncing configs and resources..."), 0.88)
                mod_count_text.value = ""

                def _extras_progress(current, total, message):
                    if total:
                        mod_count_text.value = f"{current} / {total}"
                    update_status(message, 0.88 + (0.07 * current / total) if total else 0.88)

                sync_extra_files(settings.instance_dir, progress_callback=_extras_progress)

                update_status(t("launching", "Launching Game..."), 1.0)
                launcher.launch(username=active.get("username", "Player"), version_id=version_id, exit_callback=on_game_exit)

            except Exception as err:
                logger.error(f"[DEBUG WORKER ERROR] Launch failed: {err}", exc_info=True)
                update_status(f"{t('error_prefix', 'Error')}: {err}", 0.0)
                set_play_state(False)

        threading.Thread(target=_worker, daemon=True).start()

    def update_status(msg: str = None, prog: float = None):
        if msg is not None:
            status_text.value = msg
        if prog is not None:
            progress_bar.value = prog
        page.update()

    def on_game_exit(code: int):
        set_play_state(False)
        update_status(t("ready", "Ready"), 0.0)
        mod_count_text.value = ""

    play_btn = ft.Button(
        content=ft.Row(
            controls=[
                ft.Icon(ft.Icons.PLAY_ARROW_ROUNDED),
                ft.Text(value=t("play_button", "Play"), weight=ft.FontWeight.BOLD)
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=8
        ),
        style=ft.ButtonStyle(
            color=ft.Colors.WHITE,
            bgcolor=ft.Colors.BLUE_700,
            padding=ft.Padding.symmetric(horizontal=25, vertical=15),
            shape=ft.RoundedRectangleBorder(radius=8)
        ),
        on_click=on_play_click
    )

    # ------------------------------------------------------------------ #
    #  SECTION TITLES
    # ------------------------------------------------------------------ #
    server_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    mods_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    profiles_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    news_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    language_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    settings_title = ft.Text(size=22, weight=ft.FontWeight.BOLD)
    crash_logs_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    ram_label = ft.Text()
    save_settings_btn = ft.Button(content=ft.Text(t("save_settings", "Save Settings")), on_click=lambda e: settings_mgr.save())

    mods_desc = ft.Text(color=ft.Colors.GREY_400)
    profiles_desc = ft.Text(color=ft.Colors.GREY_400)
    lang_desc = ft.Text(color=ft.Colors.GREY_400)
    crash_logs_desc = ft.Text(color=ft.Colors.GREY_400)
    screenshots_title = ft.Text(size=26, weight=ft.FontWeight.BOLD)
    screenshots_desc = ft.Text(color=ft.Colors.GREY_400)
    mod_count_label = ft.Text(size=13, color=ft.Colors.GREY_500)

    # ------------------------------------------------------------------ #
    #  OPEN FOLDER
    # ------------------------------------------------------------------ #
    def open_minecraft_folder(e):
        mc_dir = Path(settings.instance_dir)
        mc_dir.mkdir(parents=True, exist_ok=True)
        try:
            if platform.system() == "Windows":
                os.startfile(mc_dir)
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", str(mc_dir)])
            else:
                subprocess.Popen(["xdg-open", str(mc_dir)])
        except Exception as ex:
            logger.error(f"[DEBUG FOLDER ERROR] {ex}")

    open_folder_btn = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.FOLDER_OPEN, color=ft.Colors.BLUE_400),
            ft.Text(t("open_mc_folder", "Open Minecraft Folder"))
        ], spacing=8),
        on_click=open_minecraft_folder
    )

    # ------------------------------------------------------------------ #
    #  UPDATE BANNER (self-update check)
    # ------------------------------------------------------------------ #
    update_banner = ft.Container(visible=False)

    def check_updates():
        result = check_for_update()
        if result["update_available"]:
            update_banner.content = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.SYSTEM_UPDATE, color=ft.Colors.ORANGE_400),
                    ft.Column([
                        ft.Text(
                            t("update_available", "Update Available"),
                            weight=ft.FontWeight.BOLD, size=14, color=ft.Colors.ORANGE_300
                        ),
                        ft.Text(
                            t("update_available_msg", "Version {version} is available. Click to download.", version=result["latest_version"]),
                            size=12, color=ft.Colors.GREY_300
                        ),
                    ], spacing=2),
                    ft.Button(
                        content=ft.Row([
                            ft.Icon(ft.Icons.DOWNLOAD, size=16),
                            ft.Text(t("download_update", "Download"))
                        ], spacing=6, tight=True),
                        on_click=lambda e: webbrowser.open(result["download_url"])
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=12,
                bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
                border_radius=8,
            )
            update_banner.visible = True
            page.update()

    # ------------------------------------------------------------------ #
    #  MOTD
    # ------------------------------------------------------------------ #
    motd_container = ft.Container(visible=False)

    def fetch_motd():
        motd_data = None
        try:
            req = urllib.request.Request(f"{GITHUB_RAW_BASE}/api/motd.json", headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=3) as response:
                motd_data = json.loads(response.read().decode())
        except Exception:
            local_path = Path("api/motd.json")
            if local_path.exists():
                try:
                    with open(local_path, "r", encoding="utf-8") as f:
                        motd_data = json.load(f)
                except Exception:
                    pass

        if motd_data and motd_data.get("enabled", False):
            title = motd_data.get("title", t("notice", "Notice"))
            message = motd_data.get("message", "")
            btn_info = motd_data.get("button")

            controls = [
                ft.Row([
                    ft.Icon(ft.Icons.INFO_OUTLINE, color=ft.Colors.BLUE_400),
                    ft.Text(title, weight=ft.FontWeight.BOLD, size=15, color=ft.Colors.BLUE_200)
                ], spacing=8),
                ft.Text(message, size=13, color=ft.Colors.GREY_300)
            ]

            if btn_info and btn_info.get("text") and btn_info.get("url"):
                btn_url = btn_info.get("url")
                btn_text = btn_info.get("text")
                controls.append(
                    ft.Row([
                        ft.TextButton(
                            content=ft.Text(btn_text),
                            icon=ft.Icons.OPEN_IN_NEW,
                            on_click=lambda e, url=btn_url: webbrowser.open(url)
                        )
                    ], alignment=ft.MainAxisAlignment.END)
                )

            motd_container.content = ft.Container(
                content=ft.Column(controls, spacing=5),
                padding=12,
                bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
                border_radius=8
            )
            motd_container.visible = True
            page.update()

    # ------------------------------------------------------------------ #
    #  HOME VIEW
    # ------------------------------------------------------------------ #
    home_view = ft.Container(
        content=ft.Column(
            controls=[
                update_banner,
                motd_container,
                ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Text("Minecraft \U0001F1EE \U0001F1F1 ", size=64, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_300),
                            ft.Text("Play Launcher", size=16, color=ft.Colors.GREY_300),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    expand=True,
                    alignment=ft.Alignment(0, 0),
                ),
                ft.Container(
                    content=ft.Column(
                        controls=[
                            progress_bar,
                            mod_count_text,
                            status_text,
                            ft.Row(
                                controls=[username_field, play_btn],
                                alignment=ft.MainAxisAlignment.CENTER,
                                spacing=15
                            )
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=10
                    ),
                    padding=20,
                    bgcolor=ft.Colors.SURFACE_CONTAINER_HIGHEST,
                    border_radius=12
                )
            ],
            expand=True
        ),
        padding=20,
        expand=True
    )

    # ------------------------------------------------------------------ #
    #  SERVER VIEW
    # ------------------------------------------------------------------ #
    server_status_text = ft.Text(t("pinging_server", "Pinging server..."), color=ft.Colors.GREY_400)
    server_players_text = ft.Text("", size=16, weight=ft.FontWeight.BOLD)

    def fetch_server_data():
        try:
            req = urllib.request.Request("https://api.mcsrvstat.us/3/minecraft-il.duckdns.org", headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                if data.get("online"):
                    players = data.get("players", {})
                    server_status_text.value = f"{t('status_online', 'Status: Online')} \U0001F7E2"
                    server_status_text.color = ft.Colors.GREEN_400
                    server_players_text.value = f"{players.get('online', 0)} / {players.get('max', 0)} {t('players_online', 'Players Online')}"
                else:
                    server_status_text.value = f"{t('status_offline', 'Status: Offline')} \U0001F534"
                    server_status_text.color = ft.Colors.RED_400
        except Exception:
            server_status_text.value = t("server_unreachable", "Could not reach server API.")
        finally:
            page.update()

    server_view = ft.Container(
        content=ft.Column(
            controls=[
                server_title,
                ft.Container(height=20),
                ft.Image(
                    src="https://api.mcsrvstat.us/icon/minecraft-il.duckdns.org:25565",
                    width=128, height=128, border_radius=12,
                    error_content=ft.Icon(ft.Icons.ERROR_OUTLINE, size=64, color=ft.Colors.GREY_400)
                ),
                ft.Container(height=15),
                ft.Text("minecraft-il.duckdns.org:25565", size=20, color=ft.Colors.BLUE_200, selectable=True, weight=ft.FontWeight.W_600),
                server_status_text,
                server_players_text
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        ),
        alignment=ft.Alignment(0, 0),
        expand=True
    )

    # ------------------------------------------------------------------ #
    #  MODS VIEW (with search + mod details)
    # ------------------------------------------------------------------ #
    mods_list_view = ft.ListView(expand=True, spacing=10, padding=10)
    mod_search_field = ft.TextField(
        width=300, height=40,
        hint_text=t("search_mods", "Search mods..."),
        prefix_icon=ft.Icons.SEARCH,
    )

    def load_local_mods():
        nonlocal all_mods_data
        all_mods_data = []
        mods_list_view.controls.clear()
        mods_dir = Path(settings.instance_dir) / "mods"
        mods_dir.mkdir(parents=True, exist_ok=True)
        icon_cache_dir = Path(settings.instance_dir) / ".mod_icons"

        jar_files = sorted(list(mods_dir.glob("*.jar")), key=lambda f: f.name.lower())
        if jar_files:
            for mod_file in jar_files:
                # Extract metadata
                meta = {"name": mod_file.stem, "version": "", "description": ""}
                try:
                    meta = extract_mod_metadata(mod_file)
                except Exception as ex:
                    logger.warning(f"[MOD META] {mod_file.name}: {ex}")

                # Extract icon
                icon_path = None
                try:
                    icon_path = extract_mod_icon(mod_file, icon_cache_dir)
                except Exception as ex:
                    logger.warning(f"[MOD ICONS] {mod_file.name}: {ex}")

                if icon_path:
                    try:
                        icon_bytes = icon_path.read_bytes()
                        leading = ft.Image(
                            src=icon_bytes,
                            width=36, height=36,
                            border_radius=6,
                            fit=ft.BoxFit.CONTAIN,
                            error_content=ft.Icon(ft.Icons.EXTENSION, color=ft.Colors.BLUE_400),
                        )
                    except Exception:
                        leading = ft.Icon(ft.Icons.EXTENSION, color=ft.Colors.BLUE_400)
                else:
                    leading = ft.Icon(ft.Icons.EXTENSION, color=ft.Colors.BLUE_400)

                size_mb = round(mod_file.stat().st_size / (1024 * 1024), 2)

                # Build subtitle with version + size
                subtitle_parts = []
                if meta.get("version"):
                    subtitle_parts.append(f"{t('mod_version', 'Version')}: {meta['version']}")
                subtitle_parts.append(f"{t('mod_size', 'Size')}: {size_mb} MB")
                subtitle_text = " | ".join(subtitle_parts)

                # Description line
                desc_text = meta.get("description", "") or t("no_description", "No description available")
                # Truncate long descriptions
                if len(desc_text) > 120:
                    desc_text = desc_text[:117] + "..."

                mod_entry = {
                    "file": mod_file,
                    "name": meta.get("name", mod_file.stem),
                    "filename": mod_file.name,
                    "version": meta.get("version", ""),
                    "description": desc_text,
                    "size_mb": size_mb,
                    "leading": leading,
                    "subtitle_text": subtitle_text,
                }
                all_mods_data.append(mod_entry)

            mod_count_label.value = t("mod_count", "{count} mods installed", count=len(all_mods_data))
            render_mods_list()
        else:
            mod_count_label.value = ""
            mods_list_view.controls.append(
                ft.Text(t("no_mods_found", "No mod files found in .minecraft/mods"), color=ft.Colors.GREY_400)
            )
            page.update()

    def render_mods_list(query=""):
        mods_list_view.controls.clear()
        query_lower = query.lower().strip() if query else ""

        for mod in all_mods_data:
            if query_lower:
                if (query_lower not in mod["name"].lower()
                        and query_lower not in mod["filename"].lower()
                        and query_lower not in mod["description"].lower()):
                    continue

            subtitle_col = ft.Column([
                ft.Text(mod["subtitle_text"], size=12, color=ft.Colors.GREY_400),
                ft.Text(mod["description"], size=11, color=ft.Colors.GREY_500, max_lines=2),
            ], spacing=2)

            mods_list_view.controls.append(
                ft.ListTile(
                    leading=mod["leading"],
                    title=ft.Text(mod["name"], weight=ft.FontWeight.BOLD),
                    subtitle=subtitle_col,
                )
            )

        if not mods_list_view.controls:
            mods_list_view.controls.append(
                ft.Text(t("no_mods_found", "No mod files found in .minecraft/mods"), color=ft.Colors.GREY_400)
            )
        page.update()

    def on_mod_search(e):
        render_mods_list(mod_search_field.value or "")

    # Wire up search
    try:
        mod_search_field.on_change = on_mod_search
    except Exception:
        pass

    mods_view = ft.Container(
        content=ft.Column([
            mods_title,
            mods_desc,
            ft.Container(height=10),
            ft.Row([mod_search_field, mod_count_label], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Container(height=5),
            mods_list_view
        ], expand=True),
        padding=20, expand=True
    )

    # ------------------------------------------------------------------ #
    #  PROFILES VIEW
    # ------------------------------------------------------------------ #
    new_account_input = ft.TextField(width=240, height=45)
    accounts_list_column = ft.Column(spacing=10, expand=True, scroll=ft.ScrollMode.AUTO)
    add_account_btn_text = ft.Text("")

    def refresh_profiles_ui():
        accounts_list_column.controls.clear()
        active_idx = settings.active_account_index

        for idx, acc in enumerate(settings.accounts):
            is_active = (idx == active_idx)
            acc_name = acc.get("username", "Player")

            def make_switch_handler(name):
                return lambda e: [settings.switch_account(name), username_field.update(), refresh_profiles_ui()]

            def make_remove_handler(name):
                return lambda e: [settings.remove_account(name), refresh_profiles_ui()]

            accounts_list_column.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Row([
                            ft.Icon(
                                ft.Icons.CHECK_CIRCLE if is_active else ft.Icons.RADIO_BUTTON_UNCHECKED,
                                color=ft.Colors.GREEN_400 if is_active else ft.Colors.GREY_500
                            ),
                            ft.Text(acc_name, size=16, weight=ft.FontWeight.BOLD if is_active else ft.FontWeight.NORMAL),
                            ft.Container(
                                content=ft.Text(t("active", "Active"), size=10, color=ft.Colors.WHITE),
                                bgcolor=ft.Colors.GREEN_800,
                                padding=ft.Padding.symmetric(horizontal=6, vertical=2),
                                border_radius=4,
                                visible=is_active
                            )
                        ], spacing=10),
                        ft.Row([
                            ft.Button(
                                content=ft.Text(t("switch", "Switch")),
                                visible=not is_active,
                                on_click=make_switch_handler(acc_name)
                            ),
                            ft.IconButton(
                                icon=ft.Icons.DELETE_OUTLINE,
                                icon_color=ft.Colors.RED_400,
                                tooltip=t("remove", "Remove"),
                                on_click=make_remove_handler(acc_name),
                                disabled=len(settings.accounts) <= 1
                            )
                        ], spacing=5)
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    padding=ft.Padding.symmetric(horizontal=6, vertical=2),
                    border=ft.Border.all(1, ft.Colors.GREY_800),
                    border_radius=8
                )
            )
        page.update()

    def add_new_profile_click(e):
        name = new_account_input.value.strip()
        if name:
            if settings.add_account(name):
                new_account_input.value = ""
                refresh_profiles_ui()

    add_account_btn = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.ADD, size=16),
            add_account_btn_text
        ], spacing=5, tight=True),
        on_click=add_new_profile_click
    )

    profiles_view = ft.Container(
        content=ft.Column([
            profiles_title,
            profiles_desc,
            ft.Container(height=10),
            ft.Row([
                new_account_input,
                add_account_btn
            ], spacing=10),
            ft.Divider(height=20),
            accounts_list_column
        ], expand=True),
        padding=20, expand=True
    )

    # ------------------------------------------------------------------ #
    #  NEWS VIEW
    # ------------------------------------------------------------------ #
    news_list_view = ft.ListView(expand=True, spacing=10)

    def fetch_news():
        news_items = None
        try:
            req = urllib.request.Request(f"{GITHUB_RAW_BASE}/api/news.json", headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                news_items = json.loads(response.read().decode())
        except Exception:
            for local_path in [Path("api/news.json"), Path("Play-Launcher-GITHUB/api/news.json"), Path(__file__).parent / "api" / "news.json"]:
                if local_path.exists():
                    try:
                        with open(local_path, "r", encoding="utf-8") as f:
                            news_items = json.load(f)
                        break
                    except Exception:
                        pass

        news_list_view.controls.clear()
        if news_items and isinstance(news_items, list):
            for item in news_items:
                news_list_view.controls.append(
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text(item.get("title", "Update"), size=16, weight=ft.FontWeight.BOLD),
                                ft.Text(item.get("content", ""), color=ft.Colors.GREY_300)
                            ]),
                            padding=15
                        )
                    )
                )
        else:
            news_list_view.controls.append(ft.Text(t("news_load_failed", "Failed to load news"), color=ft.Colors.RED_400))
        page.update()

    news_view = ft.Container(
        content=ft.Column([news_title, news_list_view], expand=True),
        padding=20, expand=True
    )

    # ------------------------------------------------------------------ #
    #  LANGUAGE VIEW
    # ------------------------------------------------------------------ #
    def on_lang_change(e):
        nonlocal i18n
        new_lang = str(e.control.value)
        if new_lang not in ("en", "he"):
            return
        settings.set_language(new_lang)
        i18n = LocalizationManager(new_lang)
        lang_dropdown.value = new_lang
        update_ui_language()
        refresh_active_dynamic_view()

    lang_dropdown = ft.Dropdown(
        options=[
            ft.DropdownOption(key="en", text="English"),
            ft.DropdownOption(key="he", text="Hebrew / \u05E2\u05D1\u05E8\u05D9\u05EA"),
        ],
        value=current_lang,
        width=250,
        on_select=on_lang_change,
    )

    language_view = ft.Container(
        content=ft.Column(
            controls=[
                language_title,
                lang_desc,
                ft.Container(height=15),
                lang_dropdown
            ],
            spacing=10
        ),
        padding=20,
        expand=True
    )

    # ------------------------------------------------------------------ #
    #  CRASH LOG VIEWER
    # ------------------------------------------------------------------ #
    crash_logs_list_view = ft.ListView(expand=True, spacing=8)
    crash_content_text = ft.Text(selectable=True, max_lines=None, size=11)
    crash_detail_container = ft.Container(visible=False)
    _current_crash_file = {"path": None}

    def load_crash_logs():
        crash_logs_list_view.controls.clear()
        crash_detail_container.visible = False
        _current_crash_file["path"] = None

        crash_dir = Path(settings.instance_dir) / "crash-reports"
        if not crash_dir.exists():
            crash_logs_list_view.controls.append(
                ft.Text(t("no_crash_logs", "No crash reports found"), color=ft.Colors.GREY_400)
            )
            page.update()
            return

        crash_files = sorted(crash_dir.glob("crash-*.txt"), key=lambda f: f.stat().st_mtime, reverse=True)
        if not crash_files:
            crash_logs_list_view.controls.append(
                ft.Text(t("no_crash_logs", "No crash reports found"), color=ft.Colors.GREY_400)
            )
            page.update()
            return

        for cf in crash_files:
            size_kb = round(cf.stat().st_size / 1024, 1)
            filename = cf.name

            def make_view_handler(filepath):
                return lambda e: view_crash_report(filepath)

            def make_delete_handler(filepath):
                return lambda e: delete_crash_report(filepath)

            crash_logs_list_view.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.BUG_REPORT, color=ft.Colors.RED_400),
                        ft.Column([
                            ft.Text(filename, weight=ft.FontWeight.BOLD, size=13),
                            ft.Text(f"{t('mod_size', 'Size')}: {size_kb} KB", size=11, color=ft.Colors.GREY_400),
                        ], spacing=2),
                        ft.Row([
                            ft.Button(
                                content=ft.Text(t("view_crash_report", "View")),
                                on_click=make_view_handler(cf)
                            ),
                            ft.IconButton(
                                icon=ft.Icons.DELETE_OUTLINE,
                                icon_color=ft.Colors.RED_400,
                                tooltip=t("delete_crash_report", "Delete"),
                                on_click=make_delete_handler(cf)
                            ),
                        ], spacing=5),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    padding=ft.Padding.symmetric(horizontal=10, vertical=6),
                    border=ft.Border.all(1, ft.Colors.GREY_800),
                    border_radius=8
                )
            )
        page.update()

    def view_crash_report(filepath: Path):
        try:
            content = filepath.read_text(encoding="utf-8", errors="replace")
            # Limit to 50K chars to avoid UI lag
            if len(content) > 50000:
                content = content[:50000] + "\n\n... [truncated]"
            crash_content_text.value = content
            _current_crash_file["path"] = filepath

            def _copy_crash(e):
                try:
                    page.set_clipboard(content)
                    update_status(t("crash_report_copied", "Crash report copied to clipboard"))
                except Exception:
                    pass

            copy_crash_btn = ft.Button(
                content=ft.Row([
                    ft.Icon(ft.Icons.CONTENT_COPY, size=16),
                    ft.Text(t("copy_to_clipboard", "Copy to Clipboard"))
                ], spacing=6, tight=True),
                on_click=_copy_crash
            )

            crash_detail_container.content = ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Text(t("crash_report_content", "Crash Report Content"),
                             weight=ft.FontWeight.BOLD, size=14),
                        copy_crash_btn,
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Container(
                        content=ft.Column([crash_content_text], scroll=ft.ScrollMode.AUTO),
                        height=300,
                        bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
                        border_radius=8,
                        padding=10,
                    ),
                ]),
                padding=10,
            )
            crash_detail_container.visible = True
            page.update()
        except Exception as ex:
            logger.error(f"[CRASH LOG] Failed to read {filepath}: {ex}")
            update_status(f"{t('error_prefix', 'Error')}: {ex}")

    def delete_crash_report(filepath: Path):
        try:
            filepath.unlink()
            if _current_crash_file["path"] == filepath:
                crash_detail_container.visible = False
                _current_crash_file["path"] = None
            load_crash_logs()
            update_status(t("crash_report_deleted", "Crash report deleted"))
        except Exception as ex:
            logger.error(f"[CRASH LOG] Failed to delete {filepath}: {ex}")

    crash_logs_view = ft.Container(
        content=ft.Column([
            crash_logs_title,
            crash_logs_desc,
            ft.Container(height=10),
            ft.Container(
                content=crash_logs_list_view,
                expand=True,
            ),
            crash_detail_container,
        ], expand=True),
        padding=20, expand=True
    )

    # ------------------------------------------------------------------ #
    #  SCREENSHOT GALLERY
    # ------------------------------------------------------------------ #
    screenshots_grid = ft.Row(wrap=True, spacing=10, run_spacing=10, expand=True)
    screenshots_scroll = ft.Column([screenshots_grid], scroll=ft.ScrollMode.AUTO, expand=True)
    _current_screenshot = {"path": None}

    def load_screenshots():
        screenshots_grid.controls.clear()
        _current_screenshot["path"] = None

        screenshots_dir = Path(settings.instance_dir) / "screenshots"
        if not screenshots_dir.exists():
            screenshots_grid.controls.append(
                ft.Text(t("no_screenshots", "No screenshots found"), color=ft.Colors.GREY_400)
            )
            page.update()
            return

        screenshot_files = sorted(
            screenshots_dir.glob("*.png"),
            key=lambda f: f.stat().st_mtime,
            reverse=True
        )
        if not screenshot_files:
            screenshots_grid.controls.append(
                ft.Text(t("no_screenshots", "No screenshots found"), color=ft.Colors.GREY_400)
            )
            page.update()
            return

        for sf in screenshot_files[:50]:
            size_kb = round(sf.stat().st_size / 1024, 1)

            def make_view_handler(filepath):
                return lambda e: view_screenshot(filepath)

            def make_delete_handler(filepath):
                return lambda e: delete_screenshot(filepath)

            screenshots_grid.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Image(
                            src=str(sf),
                            width=160, height=120,
                            fit=ft.BoxFit.COVER,
                            border_radius=8,
                            error_content=ft.Container(
                                content=ft.Icon(ft.Icons.BROKEN_IMAGE, size=48, color=ft.Colors.GREY_600),
                                width=160, height=120,
                                alignment=ft.Alignment(0, 0),
                            ),
                        ),
                        ft.Text(sf.name, size=11, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                        ft.Text(f"{size_kb} KB", size=10, color=ft.Colors.GREY_500),
                        ft.Row([
                            ft.TextButton(
                                content=ft.Text(t("view_screenshot", "View"), size=12),
                                on_click=make_view_handler(sf)
                            ),
                            ft.IconButton(
                                icon=ft.Icons.DELETE_OUTLINE,
                                icon_color=ft.Colors.RED_400,
                                tooltip=t("delete_screenshot", "Delete"),
                                on_click=make_delete_handler(sf),
                                icon_size=18,
                            ),
                        ], spacing=0),
                    ], spacing=3, alignment=ft.MainAxisAlignment.CENTER),
                    width=185,
                    padding=8,
                    border=ft.Border.all(1, ft.Colors.GREY_800),
                    border_radius=8,
                )
            )
        page.update()

    def view_screenshot(filepath):
        _current_screenshot["path"] = filepath

        def _close_ss(e):
            try:
                page.close(ss_dialog)
            except Exception:
                ss_dialog.open = False
                page.update()

        ss_dialog = ft.AlertDialog(
            content=ft.Column([
                ft.Image(src=str(filepath), fit=ft.BoxFit.CONTAIN, width=700, height=500),
                ft.Text(filepath.name, size=12, color=ft.Colors.GREY_400),
            ], scroll=ft.ScrollMode.AUTO),
            actions=[
                ft.TextButton(t("cancel", "Close"), on_click=_close_ss),
            ],
        )
        try:
            page.open(ss_dialog)
        except Exception:
            page.dialog = ss_dialog
            ss_dialog.open = True
            page.update()

    def delete_screenshot(filepath):
        try:
            filepath.unlink()
            load_screenshots()
            update_status(t("screenshot_deleted", "Screenshot deleted"))
        except Exception as ex:
            logger.error(f"[SCREENSHOTS] Failed to delete {filepath}: {ex}")

    def open_screenshots_folder(e):
        ss_dir = Path(settings.instance_dir) / "screenshots"
        ss_dir.mkdir(parents=True, exist_ok=True)
        try:
            if platform.system() == "Windows":
                os.startfile(str(ss_dir))
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", str(ss_dir)])
            else:
                subprocess.Popen(["xdg-open", str(ss_dir)])
        except Exception as ex:
            logger.error(f"[SCREENSHOTS] Failed to open folder: {ex}")

    open_screenshots_btn = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.FOLDER_OPEN, color=ft.Colors.BLUE_400),
            ft.Text(t("open_screenshots_folder", "Open Screenshots Folder"))
        ], spacing=8),
        on_click=open_screenshots_folder
    )

    screenshots_view = ft.Container(
        content=ft.Column([
            screenshots_title,
            screenshots_desc,
            ft.Container(height=10),
            open_screenshots_btn,
            ft.Container(height=10),
            screenshots_scroll,
        ], expand=True),
        padding=20, expand=True
    )

    # ------------------------------------------------------------------ #
    #  SETTINGS VIEW (themes + reset buttons)
    # ------------------------------------------------------------------ #
    def on_ram_change(e):
        settings.ram_mb = int(e.control.value)
        ram_label.value = f"{t('ram_allocation', 'RAM Allocation')}: {settings.ram_mb} MB"
        page.update()

    ram_slider = ft.Slider(min=2048, max=16384, divisions=14, value=settings.ram_mb, label="{value} MB", on_change=on_ram_change)

    # Theme toggle
    theme_label = ft.Text(t("theme", "Theme"), size=16, weight=ft.FontWeight.BOLD)
    theme_switch = ft.Switch(
        label=t("dark_mode", "Dark Mode"),
        value=settings.theme_mode == "dark",
    )

    def on_theme_toggle(e):
        settings.theme_mode = "dark" if e.control.value else "light"
        settings_mgr.save()
        apply_theme()
        page.update()

    theme_switch.on_change = on_theme_toggle

    # Accent color
    accent_label = ft.Text(t("accent_color", "Accent Color"), size=16, weight=ft.FontWeight.BOLD)
    accent_dropdown = ft.Dropdown(
        options=[ft.DropdownOption(key=k, text=t(f"color_{k}", k.capitalize())) for k in ACCENT_COLORS],
        value=settings.accent_color,
        width=200,
    )

    def on_accent_change(e):
        new_color = str(e.control.value)
        if new_color in ACCENT_COLORS:
            settings.accent_color = new_color
            settings_mgr.save()
            apply_theme()
            page.update()

    accent_dropdown.on_select = on_accent_change

    # --- Reset buttons ---
    def show_confirm_dialog(title_text, message_text, on_confirm):
        def _confirm(e):
            try:
                page.close(dialog)
            except Exception:
                dialog.open = False
            on_confirm()
            page.update()

        def _cancel(e):
            try:
                page.close(dialog)
            except Exception:
                dialog.open = False
            page.update()

        dialog = ft.AlertDialog(
            title=ft.Text(title_text, weight=ft.FontWeight.BOLD),
            content=ft.Text(message_text),
            actions=[
                ft.TextButton(t("cancel", "Cancel"), on_click=_cancel),
                ft.TextButton(t("confirm", "Confirm"), on_click=_confirm),
            ],
        )
        try:
            page.open(dialog)
        except Exception:
            page.dialog = dialog
            dialog.open = True
            page.update()

    def on_reset_settings(e):
        show_confirm_dialog(
            t("reset_settings", "Reset Settings"),
            t("reset_settings_confirm", "Reset all settings to defaults? Your accounts and game files will be kept."),
            lambda: _do_reset_settings()
        )

    def _do_reset_settings():
        nonlocal i18n
        settings.reset_settings()
        i18n = LocalizationManager(settings.language)
        lang_dropdown.value = settings.language
        # Update UI to reflect reset
        ram_slider.value = settings.ram_mb
        ram_label.value = f"{t('ram_allocation', 'RAM Allocation')}: {settings.ram_mb} MB"
        theme_switch.value = settings.theme_mode == "dark"
        accent_dropdown.value = settings.accent_color
        apply_theme()
        update_ui_language()
        update_status(t("reset_settings_done", "Settings reset to defaults"))
        page.update()

    def on_reset_everything(e):
        show_confirm_dialog(
            t("reset_everything", "Reset Everything"),
            t("reset_everything_confirm", "WARNING: This will delete ALL game files, mods, configs, and settings. This cannot be undone. Are you sure?"),
            lambda: _do_reset_everything()
        )

    def _do_reset_everything():
        nonlocal i18n
        settings.reset_everything()
        i18n = LocalizationManager(settings.language)
        lang_dropdown.value = settings.language
        # Update all UI
        ram_slider.value = settings.ram_mb
        ram_label.value = f"{t('ram_allocation', 'RAM Allocation')}: {settings.ram_mb} MB"
        theme_switch.value = settings.theme_mode == "dark"
        accent_dropdown.value = settings.accent_color
        username_field.value = settings.get_active_account().get("username", "Player")
        apply_theme()
        update_ui_language()
        refresh_profiles_ui()
        update_status(t("reset_everything_done", "Everything has been reset"))
        page.update()

    reset_settings_btn = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.RESTORE, size=16),
            ft.Text(t("reset_settings", "Reset Settings"))
        ], spacing=6, tight=True),
        on_click=on_reset_settings
    )

    reset_everything_btn = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.DELETE_FOREVER, size=16, color=ft.Colors.RED_400),
            ft.Text(t("reset_everything", "Reset Everything"))
        ], spacing=6, tight=True),
        style=ft.ButtonStyle(
            bgcolor=ft.Colors.RED_900,
            color=ft.Colors.WHITE,
        ),
        on_click=on_reset_everything
    )

    # Initialize labels
    ram_label.value = f"{t('ram_allocation', 'RAM Allocation')}: {settings.ram_mb} MB"

    settings_view = ft.Container(
        content=ft.Column(
            controls=[
                settings_title,
                ft.Container(height=10),
                ram_label,
                ram_slider,
                ft.Divider(height=20),
                theme_label,
                theme_switch,
                ft.Container(height=5),
                accent_label,
                accent_dropdown,
                ft.Divider(height=20),
                open_folder_btn,
                ft.Container(height=10),
                save_settings_btn,
                ft.Divider(height=20),
                reset_settings_btn,
                ft.Container(height=10),
                reset_everything_btn,
            ],
            spacing=10
        ),
        padding=20,
        expand=True
    )

    # ------------------------------------------------------------------ #
    #  NAVIGATION
    # ------------------------------------------------------------------ #
    views = [home_view, server_view, mods_view, screenshots_view, profiles_view, news_view, language_view, settings_view, crash_logs_view]
    body_container = ft.Container(content=home_view, expand=True)

    def refresh_dynamic_view(idx: int):
        if idx == 0:
            threading.Thread(target=fetch_motd, daemon=True).start()
        elif idx == 1:
            server_status_text.value = t("pinging_server", "Pinging server...")
            threading.Thread(target=fetch_server_data, daemon=True).start()
        elif idx == 2:
            load_local_mods()
        elif idx == 3:
            load_screenshots()
        elif idx == 4:
            refresh_profiles_ui()
        elif idx == 5:
            threading.Thread(target=fetch_news, daemon=True).start()
        elif idx == 8:
            load_crash_logs()

    def refresh_active_dynamic_view():
        refresh_dynamic_view(rail.selected_index)
        page.update()

    def nav_change(e):
        idx = e.control.selected_index
        body_container.content = views[idx]
        refresh_dynamic_view(idx)
        page.update()

    rail = ft.NavigationRail(
        selected_index=0,
        label_type=ft.NavigationRailLabelType.ALL,
        min_width=75,
        min_extended_width=200,
        group_alignment=-0.9,
        destinations=[
            ft.NavigationRailDestination(icon=ft.Icons.HOME_OUTLINED, selected_icon=ft.Icons.HOME, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.DNS_OUTLINED, selected_icon=ft.Icons.DNS, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.EXTENSION_OUTLINED, selected_icon=ft.Icons.EXTENSION, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.PHOTO_LIBRARY, selected_icon=ft.Icons.PHOTO_LIBRARY, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.PEOPLE_OUTLINED, selected_icon=ft.Icons.PEOPLE, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.NEWSPAPER_OUTLINED, selected_icon=ft.Icons.NEWSPAPER, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.LANGUAGE, selected_icon=ft.Icons.LANGUAGE, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.SETTINGS_OUTLINED, selected_icon=ft.Icons.SETTINGS, label=""),
            ft.NavigationRailDestination(icon=ft.Icons.BUG_REPORT, selected_icon=ft.Icons.BUG_REPORT, label=""),
        ],
        on_change=nav_change
    )

    def update_ui_language():
        page.title = t("app_title", "Play Launcher")
        page.rtl = i18n.is_rtl()

        username_field.label = t("username_prompt", "Username")
        if not game_process_running:
            play_btn.content.controls[1].value = t("play_button", "Play")
        else:
            play_btn.content.controls[1].value = t("stop_button", "Stop Game")
        status_text.value = t("ready", "Ready") if status_text.value in ["Ready", "\u05DE\u05D5\u05DB\u05DF"] else status_text.value

        server_title.value = t("server_title", "Featured Server Status")
        mods_title.value = t("mods_title", "Mods Manager")
        profiles_title.value = t("profiles_title", "Profiles")
        news_title.value = t("news_title", "News")
        language_title.value = t("language_title", "Language Settings")
        settings_title.value = t("settings_title", "Settings")
        crash_logs_title.value = t("crash_logs_title", "Crash Logs")
        screenshots_title.value = t("screenshots_title", "Screenshot Gallery")

        mods_desc.value = t("mods_desc", "Showing local contents of .minecraft/mods")
        profiles_desc.value = t("profiles_desc", "Manage offline and active user profiles")
        lang_desc.value = t("lang_desc", "Choose your preferred UI language")
        crash_logs_desc.value = t("crash_logs_desc", "View and manage game crash reports")
        screenshots_desc.value = t("screenshots_desc", "Browse and manage game screenshots")

        new_account_input.hint_text = t("enter_username", "Enter new username...")
        add_account_btn_text.value = t("add_account", "Add Account")
        ram_label.value = f"{t('ram_allocation', 'RAM Allocation')}: {settings.ram_mb} MB"
        open_folder_btn.content.controls[1].value = t("open_mc_folder", "Open Minecraft Folder")
        open_screenshots_btn.content.controls[1].value = t("open_screenshots_folder", "Open Screenshots Folder")
        save_settings_btn.content.value = t("save_settings", "Save Settings")

        mod_search_field.hint_text = t("search_mods", "Search mods...")
        mod_count_label.value = t("mod_count", "{count} mods installed", count=len(all_mods_data)) if all_mods_data else ""

        theme_label.value = t("theme", "Theme")
        theme_switch.label = t("dark_mode", "Dark Mode")
        accent_label.value = t("accent_color", "Accent Color")
        accent_dropdown.options = [ft.DropdownOption(key=k, text=t(f"color_{k}", k.capitalize())) for k in ACCENT_COLORS]
        reset_settings_btn.content.controls[1].value = t("reset_settings", "Reset Settings")
        reset_everything_btn.content.controls[1].value = t("reset_everything", "Reset Everything")

        rail.destinations[0].label = t("nav_home", "Home")
        rail.destinations[1].label = t("nav_server", "Server")
        rail.destinations[2].label = t("nav_mods", "Mods")
        rail.destinations[3].label = t("nav_screenshots", "Screenshots")
        rail.destinations[4].label = t("nav_profiles", "Profiles")
        rail.destinations[5].label = t("nav_news", "News")
        rail.destinations[6].label = t("nav_language", "Language")
        rail.destinations[7].label = t("nav_settings", "Settings")
        rail.destinations[8].label = t("nav_crash_logs", "Crash Logs")

        refresh_profiles_ui()
        page.update()

    # ------------------------------------------------------------------ #
    #  STARTUP
    # ------------------------------------------------------------------ #
    threading.Thread(target=fetch_motd, daemon=True).start()
    threading.Thread(target=check_updates, daemon=True).start()
    update_ui_language()

    page.add(
        ft.Row(
            controls=[rail, ft.VerticalDivider(width=1), body_container],
            expand=True,
            spacing=0
        )
    )

    threading.Thread(target=fetch_news, daemon=True).start()


if __name__ == "__main__":
    ft.run(main)