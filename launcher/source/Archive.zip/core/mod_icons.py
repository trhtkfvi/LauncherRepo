"""
Extracts mod icons from local .jar files for display on the Mods page.

Supports the three metadata formats mods ship with:
- Fabric:        fabric.mod.json -> "icon" (string path, or dict of size->path)
- Forge (modern): META-INF/mods.toml -> logoFile
- Forge (legacy): mcmod.info -> logoFile

Extracted icons are cached to disk next to the mods themselves so we only
read/unzip each jar once. Cache is invalidated automatically if the jar's
size or mtime changes (i.e. the mod file was updated).
"""

import json
import re
import zipfile
from pathlib import Path
from typing import Optional

try:
    from utils.logger import get_logger
    logger = get_logger()
except ImportError:
    import logging
    logger = logging.getLogger("ModIcons")

CACHE_DIRNAME = ".mod_icons"


def _safe_cache_name(jar_path: Path) -> str:
    """Sanitizes a jar filename into a safe cache filename."""
    stem = re.sub(r"[^A-Za-z0-9_.-]", "_", jar_path.stem)
    return f"{stem}.png"


def _read_fabric_icon(zf: zipfile.ZipFile) -> Optional[bytes]:
    try:
        with zf.open("fabric.mod.json") as f:
            data = json.load(f)
        icon_ref = data.get("icon")
        if isinstance(icon_ref, dict):
            # e.g. {"16": "assets/mod/icon16.png", "128": "assets/mod/icon128.png"}
            icon_ref = sorted(icon_ref.items(), key=lambda kv: int(kv[0]) if str(kv[0]).isdigit() else 0)[-1][1]
        if isinstance(icon_ref, str) and icon_ref in zf.namelist():
            return zf.read(icon_ref)
    except Exception:
        pass
    return None


def _read_forge_toml_icon(zf: zipfile.ZipFile) -> Optional[bytes]:
    try:
        with zf.open("META-INF/mods.toml") as f:
            text = f.read().decode("utf-8", errors="ignore")
        match = re.search(r'logoFile\s*=\s*"([^"]+)"', text)
        if match:
            logo_path = match.group(1)
            if logo_path in zf.namelist():
                return zf.read(logo_path)
    except Exception:
        pass
    return None


def _read_legacy_mcmod_icon(zf: zipfile.ZipFile) -> Optional[bytes]:
    try:
        with zf.open("mcmod.info") as f:
            raw = f.read().decode("utf-8", errors="ignore")
        data = json.loads(raw)
        entries = data if isinstance(data, list) else data.get("modList", data)
        if isinstance(entries, list) and entries:
            logo_path = entries[0].get("logoFile")
            if logo_path:
                logo_path = logo_path.lstrip("/")
                if logo_path in zf.namelist():
                    return zf.read(logo_path)
    except Exception:
        pass
    return None


def extract_mod_icon(jar_path: Path, cache_dir: Path) -> Optional[Path]:
    """
    Returns a Path to a cached PNG icon for the given mod jar, extracting
    it from the jar's own metadata if not already cached. Returns None if
    the jar has no discoverable icon.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / _safe_cache_name(jar_path)

    if cache_file.exists() and cache_file.stat().st_mtime >= jar_path.stat().st_mtime:
        return cache_file

    icon_bytes = None
    try:
        with zipfile.ZipFile(jar_path, "r") as zf:
            names = zf.namelist()
            if "fabric.mod.json" in names:
                icon_bytes = _read_fabric_icon(zf)
            if icon_bytes is None and "META-INF/mods.toml" in names:
                icon_bytes = _read_forge_toml_icon(zf)
            if icon_bytes is None and "mcmod.info" in names:
                icon_bytes = _read_legacy_mcmod_icon(zf)
    except Exception as ex:
        logger.warning(f"[MOD ICONS] Failed to read {jar_path.name}: {ex}")
        return None

    if icon_bytes:
        try:
            with open(cache_file, "wb") as f:
                f.write(icon_bytes)
            return cache_file
        except Exception as ex:
            logger.warning(f"[MOD ICONS] Failed to cache icon for {jar_path.name}: {ex}")
            return None

    return None
