"""Extract mod name, version, and description from .jar files.

Supports:
  - Fabric  (fabric.mod.json)
  - Forge 1.13+  (META-INF/mods.toml)
  - Legacy Forge  (mcmod.info)
"""

import json
import zipfile
from pathlib import Path

try:
    from utils.logger import get_logger
    logger = get_logger()
except ImportError:
    import logging
    logger = logging.getLogger("mod_metadata")

# tomllib is stdlib in Python 3.11+; fall back to tomli, then to a simple parser
try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None


def extract_mod_metadata(jar_path: Path) -> dict:
    """Return {'name', 'version', 'description'} for a mod jar.

    Falls back to the filename stem if no metadata is found.
    """
    result = {
        "name": jar_path.stem,
        "version": "",
        "description": "",
    }

    try:
        with zipfile.ZipFile(jar_path, "r") as zf:
            names = zf.namelist()

            # --- Fabric ---
            if "fabric.mod.json" in names:
                try:
                    data = json.loads(zf.read("fabric.mod.json"))
                    result["name"] = data.get("name", result["name"])
                    result["version"] = data.get("version", "")
                    result["description"] = data.get("description", "")
                    return result
                except Exception as ex:
                    logger.debug(f"[MOD META] fabric.mod.json parse failed in {jar_path.name}: {ex}")

            # --- Forge 1.13+ (mods.toml) ---
            if "META-INF/mods.toml" in names:
                try:
                    raw = zf.read("META-INF/mods.toml").decode("utf-8")
                    parsed = _parse_toml(raw)
                    mods = parsed.get("mods", [])
                    if mods and isinstance(mods, list) and len(mods) > 0:
                        mod = mods[0]
                        result["name"] = mod.get("displayName") or mod.get("modId") or result["name"]
                        result["version"] = mod.get("version", "")
                        result["description"] = mod.get("description", "")
                        return result
                except Exception as ex:
                    logger.debug(f"[MOD META] mods.toml parse failed in {jar_path.name}: {ex}")

            # --- Legacy Forge (mcmod.info) ---
            if "mcmod.info" in names:
                try:
                    data = json.loads(zf.read("mcmod.info"))
                    if isinstance(data, list) and len(data) > 0:
                        mod = data[0]
                    elif isinstance(data, dict):
                        mod_list = data.get("modList", [])
                        mod = mod_list[0] if mod_list else {}
                    else:
                        mod = {}
                    result["name"] = mod.get("name", result["name"])
                    result["version"] = mod.get("version", "")
                    result["description"] = mod.get("description", "")
                    return result
                except Exception as ex:
                    logger.debug(f"[MOD META] mcmod.info parse failed in {jar_path.name}: {ex}")

    except Exception as ex:
        logger.warning(f"[MOD META] Could not read jar {jar_path.name}: {ex}")

    return result


def _parse_toml(toml_str: str) -> dict:
    """Parse a mods.toml string using tomllib if available, otherwise a simple fallback."""
    if tomllib is not None:
        return tomllib.loads(toml_str)
    return _parse_toml_simple(toml_str)


def _parse_toml_simple(toml_str: str) -> dict:
    """Minimal TOML parser for mods.toml — handles [[mods]] sections and key=value pairs."""
    result: dict = {"mods": []}
    current_section = None
    current_mod: dict = {}

    for line in toml_str.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[["):
            if current_mod:
                result.setdefault("mods", []).append(current_mod)
            current_mod = {}
            current_section = line.strip("[]")
        elif line.startswith("["):
            if current_mod and current_section and "mods" in current_section:
                result.setdefault("mods", []).append(current_mod)
                current_mod = {}
            current_section = line.strip("[]")
        elif "=" in line:
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            # strip surrounding quotes
            if (value.startswith('"') and value.endswith('"')) or (
                value.startswith("'") and value.endswith("'")
            ):
                value = value[1:-1]
            if current_section and "mods" in current_section:
                current_mod[key] = value
            else:
                result[key] = value

    if current_mod:
        result.setdefault("mods", []).append(current_mod)

    return result
