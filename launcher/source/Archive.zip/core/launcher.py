"""
Spawns the actual Minecraft/Forge process.

`version_id` must be the id returned by MinecraftInstaller.install_forge()
(e.g. "1.20.1-forge-47.4.10") - not a hardcoded string. The old code hardcoded
"1.20.1-forge-47.3.0" here while installer.py installed
"1.20.1-forge-47.4.10" - a mismatch that meant the version jar was never
found and silently dropped from the classpath. It also built the classpath
by hand; that's what actually produced the NoClassDefFoundError, since a
hand-built classpath can't know about every library Forge's real install
needs. Both problems go away by using minecraft-launcher-lib to build the
command from the version JSON that install_forge() just wrote.
"""

import platform
import subprocess
import threading
from pathlib import Path

import minecraft_launcher_lib as mll

from core.java import JavaManager
from utils.logger import get_logger

logger = get_logger()


class MinecraftLauncher:
    def __init__(self, settings):
        self.settings = settings
        # Always launch from the same directory mods were synced into -
        # settings.instance_dir is the single source of truth (see utils/paths.py).
        self.mc_dir = Path(settings.instance_dir)

    def launch(self, username: str, version_id: str, exit_callback=None):
        try:
            logger.info(f"[DEBUG LAUNCHER] Preparing launch for user: {username} (version: {version_id})")

            java_bin = JavaManager().resolve_java_binary(self.settings.java_path)
            account = self.settings.get_active_account() or {}
            ram_mb = getattr(self.settings, "ram_mb", 4096)

            options = {
                "username": username,
                "uuid": account.get("uuid", "00000000-0000-0000-0000-000000000000"),
                "token": "0",  # offline-style accounts don't need a real access token
                "executablePath": java_bin,
                "jvmArguments": [f"-Xmx{ram_mb}M", "-Xms1024M"],
                "launcherName": "Play Launcher",
                "launcherVersion": "1.0.0",
                "gameDirectory": str(self.mc_dir.resolve()),
            }

            command = mll.command.get_minecraft_command(version_id, str(self.mc_dir), options)

            logger.info(f"[DEBUG LAUNCHER] Executing command on {platform.system()}")

            process = subprocess.Popen(
                command,
                cwd=str(self.mc_dir.resolve()),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
            )

            def _monitor_output():
                for line in process.stdout:
                    logger.info(f"[Java Output] {line.strip()}")
                code = process.wait()
                logger.info(f"[DEBUG LAUNCHER] Process finished with exit code {code}")
                if exit_callback:
                    exit_callback(code)

            threading.Thread(target=_monitor_output, daemon=True).start()

        except Exception as ex:
            logger.error(f"[DEBUG LAUNCHER ERROR] Failed to launch game: {ex}", exc_info=True)
            if exit_callback:
                exit_callback(-1)