"""
Handles installing Minecraft + Forge for the launcher.

Previously this hand-rolled the Forge install by (a) copying the vanilla jar
and renaming it as if it were the Forge jar, and (b) downloading exactly one
library (bootstraplauncher-1.1.2.jar). Real Forge installs need a full
library set (ModLauncher, securejarhandler, several ASM jars, JarJarFileSystems,
etc.) plus a version JSON describing the main class, libraries and arguments.
Since almost all of that was missing, Java failed on the very first class
BootstrapLauncher touches (cpw/mods/cl/ModuleClassLoader, which lives in
securejarhandler - a jar that was never downloaded).

This version delegates to `minecraft-launcher-lib` (pip install
minecraft-launcher-lib), which talks to Forge's real installer/maven and
Mojang's version manifest, and writes out a correct install.

Note: Forge's developers ask launcher authors not to automate downloading/
installing Forge, since their project is funded by ads on the download page
(https://files.minecraftforge.net). minecraft-launcher-lib does it anyway, as
do most third-party launchers (MultiMC, Prism, ATLauncher, etc.) - worth
knowing in case it matters to you.
"""

from pathlib import Path

import minecraft_launcher_lib as mll
from minecraft_launcher_lib.exceptions import VersionNotFound, UnsupportedVersion

from utils.logger import get_logger

logger = get_logger()


class MinecraftInstaller:
    def __init__(self, instance_dir: str = None):
        # Falls back to the shared default only if the caller doesn't pass
        # settings.instance_dir explicitly - always prefer the caller's value
        # so install/launch/mod-sync agree on one directory.
        from utils.paths import get_minecraft_dir
        self.mc_dir = Path(instance_dir) if instance_dir else get_minecraft_dir()

    @staticmethod
    def _build_callback(status_callback):
        """Adapts our (message, fraction) callback into mll's CallbackDict shape."""
        progress_state = {"max": 0}

        def set_status(message):
            if status_callback:
                status_callback(message, None)

        def set_max(value):
            progress_state["max"] = value or 0

        def set_progress(value):
            if status_callback and progress_state["max"]:
                status_callback(None, value / progress_state["max"])

        return {"setStatus": set_status, "setProgress": set_progress, "setMax": set_max}

    def install_forge(
        self,
        minecraft_version: str,
        forge_version: str,
        java_bin: str = None,
        status_callback=None,
    ) -> str:
        """
        Installs vanilla Minecraft (if missing) + Forge for the given versions.
        Safe to call every launch: it verifies/repairs an existing install and
        only downloads what's missing or corrupted.

        Returns the installed version id (e.g. "1.20.1-forge-47.4.10").
        Pass this straight into MinecraftLauncher.launch() - do not hardcode
        a version string anywhere else, that mismatch is what caused the
        launcher to silently skip the version jar before.
        """
        if status_callback:
            status_callback(
                f"Installing Forge {forge_version} for Minecraft {minecraft_version}...", 0.0
            )

        loader = mll.mod_loader.get_mod_loader("forge")

        if not loader.is_minecraft_version_supported(minecraft_version):
            raise UnsupportedVersion(f"Forge does not support Minecraft {minecraft_version}")

        try:
            installed_version = loader.install(
                minecraft_version,
                str(self.mc_dir),
                loader_version=forge_version,
                callback=self._build_callback(status_callback),
                java=java_bin,
            )
        except VersionNotFound:
            available = loader.get_loader_versions(minecraft_version, False)
            logger.error(
                f"[DEBUG INSTALLER] Forge {forge_version} not found for {minecraft_version}. "
                f"Available versions include: {available[:10]}"
            )
            raise

        logger.info(f"[DEBUG INSTALLER] Forge ready, installed as version id: {installed_version}")
        return installed_version