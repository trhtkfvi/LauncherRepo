import json
import os
import re
import shutil
import uuid as uuid_lib
from pathlib import Path

from utils.paths import get_user_home, get_minecraft_dir

# Define standard base directories following standard paths (~/.play_launcher/.minecraft/)
# get_minecraft_dir() resolves the Windows profile folder correctly even when
# HOME is set by a POSIX-emulation shell (Git Bash/MSYS2), which previously
# caused mods to download to a different folder than the one the game launched from.
HOME_DIR = get_user_home()
BASE_DIR = get_minecraft_dir()

class SettingsManager:
    def __init__(self, settings_path="config.json"):
        self.settings_path = Path(settings_path)
        
        # General Launcher Settings
        self.ram_mb = 4096
        self.java_path = ""
        self.language = "en"
        self.theme_mode = "dark"
        self.accent_color = "blue"
        self.fullscreen = False
        self.close_on_launch = False
        self.manifest_path = ""
        self.manifest_url = ""
        self.instance_dir = str(BASE_DIR)
        self._correct_instance_dir = str(BASE_DIR)
        
        # Multi-Account Profile Management
        self.accounts = [
            {"username": "Arieldev", "uuid": str(uuid_lib.uuid4()), "type": "offline"}
        ]
        self.active_account_index = 0
        
        self.load()
        self._normalize_instance_dir()

    def _normalize_instance_dir(self):
        r"""
        Repairs an instance_dir saved by a previous buggy home-directory
        resolution. Only repairs paths that look like the specific bug we
        saw in the wild: a POSIX-style home path such as /home/<user>/... or
        C:\home\<user>\... (produced when HOME is set by a POSIX-emulation
        shell like Git Bash/MSYS2 instead of the real Windows profile
        folder). We deliberately do NOT touch any other custom instance_dir
        a user may have set on purpose - only these two clearly-broken
        shapes get auto-corrected and re-saved.
        """
        raw = self.instance_dir
        current_norm = raw.replace("\\", "/")
        expected_norm = self._correct_instance_dir.replace("\\", "/")
        suffix_norm = str(Path(".play_launcher") / ".minecraft").replace("\\", "/")

        if current_norm == expected_norm:
            return
        if not current_norm.endswith(suffix_norm):
            return

        looks_like_bad_posix_home = (
            current_norm.startswith("/home/")
            or re.match(r"^[A-Za-z]:[\\/]?home[\\/]", raw) is not None
        )
        if looks_like_bad_posix_home:
            self.instance_dir = self._correct_instance_dir
            self.save()

    def get(self):
        """Returns the settings manager instance for compatibility with .get() calls."""
        return self

    @property
    def username(self) -> str:
        """Backward compatibility property returning the active account's username."""
        acc = self.get_active_account()
        return acc.get("username", "Player") if acc else "Player"

    @username.setter
    def username(self, value: str):
        """Backward compatibility setter updating the active account's username."""
        acc = self.get_active_account()
        if acc:
            acc["username"] = value
        else:
            self.accounts.append({"username": value, "uuid": str(uuid_lib.uuid4()), "type": "offline"})
            self.active_account_index = len(self.accounts) - 1
        self.save()

    def get_active_account(self) -> dict:
        """Retrieves the currently selected account profile dictionary."""
        if not self.accounts:
            self.accounts = [{"username": "Arieldev", "uuid": str(uuid_lib.uuid4()), "type": "offline"}]
            self.active_account_index = 0
        if self.active_account_index >= len(self.accounts):
            self.active_account_index = 0
        return self.accounts[self.active_account_index]

    def add_account(self, username: str, account_type: str = "offline", account_uuid: str = None) -> bool:
        """Adds a new user account profile if it doesn't already exist."""
        username = username.strip()
        if not username:
            return False
            
        for acc in self.accounts:
            if acc["username"].lower() == username.lower():
                return False

        new_uuid = account_uuid or str(uuid_lib.uuid4())
        self.accounts.append({
            "username": username,
            "uuid": new_uuid,
            "type": account_type
        })
        self.save()
        return True

    def switch_account(self, username: str) -> bool:
        """Switches the active account profile by username."""
        for idx, acc in enumerate(self.accounts):
            if acc["username"].lower() == username.lower():
                self.active_account_index = idx
                self.save()
                return True
        return False

    def remove_account(self, username: str) -> bool:
        """Removes an account profile by username."""
        if len(self.accounts) <= 1:
            return False

        for idx, acc in enumerate(self.accounts):
            if acc["username"].lower() == username.lower():
                self.accounts.pop(idx)
                if self.active_account_index >= len(self.accounts):
                    self.active_account_index = len(self.accounts) - 1
                self.save()
                return True
        return False

    def load(self):
        """Loads settings and account profiles from disk if configuration file exists."""
        if self.settings_path.exists():
            try:
                with open(self.settings_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if "username" in data and "accounts" not in data:
                        self.accounts = [{"username": data["username"], "uuid": str(uuid_lib.uuid4()), "type": "offline"}]
                    for key, value in data.items():
                        if hasattr(self, key):
                            setattr(self, key, value)
            except Exception as e:
                print(f"Failed to load settings: {e}")

    def save(self):
        """Persists all settings and account profiles to disk."""
        try:
            data = {
                "ram_mb": self.ram_mb,
                "java_path": self.java_path,
                "language": self.language,
                "theme_mode": self.theme_mode,
                "accent_color": self.accent_color,
                "fullscreen": self.fullscreen,
                "close_on_launch": self.close_on_launch,
                "manifest_path": self.manifest_path,
                "manifest_url": self.manifest_url,
                "instance_dir": self.instance_dir,
                "accounts": self.accounts,
                "active_account_index": self.active_account_index
            }
            with open(self.settings_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Failed to save settings: {e}")

    def set_language(self, lang_code: str):
        """Updates and immediately saves the language preference."""
        self.language = lang_code
        self.save()

    def update_setting(self, key: str, value):
        """Generic setter that updates and saves any configuration attribute."""
        if hasattr(self, key):
            setattr(self, key, value)
            self.save()

    def reset_settings(self):
        """Reset all settings to defaults. Keeps accounts and instance_dir."""
        self.ram_mb = 4096
        self.java_path = ""
        self.language = "en"
        self.theme_mode = "dark"
        self.accent_color = "blue"
        self.fullscreen = False
        self.close_on_launch = False
        self.manifest_path = ""
        self.manifest_url = ""
        self.active_account_index = 0
        self.save()

    def reset_everything(self):
        """Reset everything: settings to defaults, wipe .minecraft, reset accounts."""
        # Remember the current instance dir so we delete the RIGHT folder
        old_instance_dir = Path(self.instance_dir)

        self.ram_mb = 4096
        self.java_path = ""
        self.language = "en"
        self.theme_mode = "dark"
        self.accent_color = "blue"
        self.fullscreen = False
        self.close_on_launch = False
        self.manifest_path = ""
        self.manifest_url = ""
        self.instance_dir = str(BASE_DIR)
        self._correct_instance_dir = str(BASE_DIR)
        self.accounts = [{"username": "Arieldev", "uuid": str(uuid_lib.uuid4()), "type": "offline"}]
        self.active_account_index = 0

        # Wipe the .minecraft directory that was actually in use
        if old_instance_dir.exists():
            shutil.rmtree(old_instance_dir, ignore_errors=True)

        self.save()

# Backward compatibility alias
LauncherSettings = SettingsManager
