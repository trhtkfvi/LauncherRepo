import logging

try:
    from utils.logger import get_logger
    logger = get_logger()
except ImportError:
    logger = logging.getLogger("LocalizationManager")

class LocalizationManager:
    def __init__(self, lang_code: str = "en"):
        self.lang_code = lang_code if lang_code in ["en", "he"] else "en"
        logger.info(f"[DEBUG LANG INIT] Initializing LocalizationManager with language code: '{self.lang_code}'")
        
        self.translations = {
            "en": {
                "app_title": "Play Launcher",
                "ready": "Ready",
                "play_button": "Play",
                "stop_button": "Stop Game",
                "stopping": "Stopping process...",
                "username_prompt": "Username",
                "updating": "Syncing Mods via manifest.json...",
                "launching": "Launching Game...",
                "server_title": "Featured Server Status",
                "mods_title": "Mods Manager",
                "profiles_title": "Profiles",
                "news_title": "News",
                "settings_title": "Settings",
                "ram_allocation": "RAM Allocation",
                "language": "Language",
                "language_title": "Language Settings",
                "lang_desc": "Choose your preferred UI language",
                "open_mc_folder": "Open Minecraft Folder",
                "save_settings": "Save Settings",
                "mods_desc": "Showing local contents of .minecraft/mods",
                "profiles_desc": "Manage offline and active user profiles",
                "nav_home": "Home",
                "nav_server": "Server",
                "nav_mods": "Mods",
                "nav_profiles": "Profiles",
                "nav_news": "News",
                "nav_language": "Language",
                "nav_settings": "Settings",
                "nav_crash_logs": "Crash Logs",
                "add_account": "Add Account",
                "switch": "Switch",
                "remove": "Remove",
                "active": "Active",
                "enter_username": "Enter new username...",
                "resolving_java": "Resolving Java Runtime...",
                "reading_manifest": "Reading modpack manifest...",
                "installing_forge": "Installing Forge {version}...",
                "pinging_server": "Pinging server...",
                "status_online": "Status: Online",
                "status_offline": "Status: Offline",
                "players_online": "Players Online",
                "server_unreachable": "Could not reach server API.",
                "no_mods_found": "No mod files found in .minecraft/mods",
                "news_load_failed": "Failed to load news",
                "error_prefix": "Error",
                "mod_size": "Size",
                "notice": "Notice",
                # --- Crash logs ---
                "crash_logs_title": "Crash Logs",
                "crash_logs_desc": "View and manage game crash reports",
                "no_crash_logs": "No crash reports found",
                "crash_report_content": "Crash Report Content",
                "copy_to_clipboard": "Copy to Clipboard",
                "delete_crash_report": "Delete",
                "crash_report_copied": "Crash report copied to clipboard",
                "crash_report_deleted": "Crash report deleted",
                "view_crash_report": "View",
                # --- Mod details ---
                "search_mods": "Search mods...",
                "mod_version": "Version",
                "mod_description": "Description",
                "no_description": "No description available",
                "mod_count": "{count} mods installed",
                # --- Self-update ---
                "update_available": "Update Available",
                "update_available_msg": "Version {version} is available. Click to download.",
                "download_update": "Download",
                "checking_updates": "Checking for updates...",
                "up_to_date": "Launcher is up to date",
                # --- Themes ---
                "theme": "Theme",
                "dark_mode": "Dark Mode",
                "light_mode": "Light Mode",
                "accent_color": "Accent Color",
                # --- Reset ---
                "reset_settings": "Reset Settings",
                "reset_everything": "Reset Everything",
                "reset_settings_confirm": "Reset all settings to defaults? Your accounts and game files will be kept.",
                "reset_everything_confirm": "WARNING: This will delete ALL game files, mods, configs, and settings. This cannot be undone. Are you sure?",
                "reset_settings_done": "Settings reset to defaults",
                "reset_everything_done": "Everything has been reset",
                "confirm": "Confirm",
                "cancel": "Cancel",
                # --- File sync ---
                "syncing_extras": "Syncing configs and resources...",
                "extras_synced": "Configs and resources synced",
                "extras_sync_failed": "Failed to sync some files",
                # --- Per-mod progress ---
                "downloading_mod": "Downloading: {name} ({current}/{total})",
            },
            "he": {
                "app_title": "פליי לאנצ'ר",
                "ready": "מוכן",
                "play_button": "שחק",
                "stop_button": "עצור משחק",
                "stopping": "מפסיק תהליך...",
                "username_prompt": "שם משתמש",
                "updating": "מסנכרן מודים דרך manifest.json...",
                "launching": "מפעיל משחק...",
                "server_title": "סטטוס שרת מומלץ",
                "mods_title": "מנהל מודים",
                "profiles_title": "פרופילים",
                "news_title": "חדשות",
                "settings_title": "הגדרות",
                "ram_allocation": "הקצאת זיכרון RAM",
                "language": "שפה",
                "language_title": "הגדרות שפה",
                "lang_desc": "בחר את השפה המועדפת עליך",
                "open_mc_folder": "פתח תיקיית מיינקראפט",
                "save_settings": "שמור הגדרות",
                "mods_desc": "מציג תוכן מקומי של .minecraft/mods",
                "profiles_desc": "נהל פרופילים משתמשים",
                "nav_home": "בית",
                "nav_server": "שרת",
                "nav_mods": "מודים",
                "nav_profiles": "פרופילים",
                "nav_news": "חדשות",
                "nav_language": "שפה",
                "nav_settings": "הגדרות",
                "nav_crash_logs": "דוחות קריסה",
                "add_account": "הוסף חשבון",
                "switch": "החלף",
                "remove": "הסר",
                "active": "פעיל",
                "enter_username": "הכנס שם משתמש חדש...",
                "resolving_java": "מאתר סביבת ריצה של Java...",
                "reading_manifest": "קורא את קובץ המודים...",
                "installing_forge": "מתקין Forge {version}...",
                "pinging_server": "בודק זמינות שרת...",
                "status_online": "סטטוס: מחובר",
                "status_offline": "סטטוס: לא מחובר",
                "players_online": "שחקנים מחוברים",
                "server_unreachable": "לא ניתן להתחבר לשרת.",
                "no_mods_found": "לא נמצאו קבצי מודים בתיקיית .minecraft/mods",
                "news_load_failed": "טעינת החדשות נכשלה",
                "error_prefix": "שגיאה",
                "mod_size": "גודל",
                "notice": "הודעה",
                # --- דוחות קריסה ---
                "crash_logs_title": "דוחות קריסה",
                "crash_logs_desc": "צפה ונהל דוחות קריסה של המשחק",
                "no_crash_logs": "לא נמצאו דוחות קריסה",
                "crash_report_content": "תוכן דוח הקריסה",
                "copy_to_clipboard": "העתק ללוח",
                "delete_crash_report": "מחק",
                "crash_report_copied": "דוח הקריסה הועתק ללוח",
                "crash_report_deleted": "דוח הקריסה נמחק",
                "view_crash_report": "צפה",
                # --- פרטי מודים ---
                "search_mods": "חיפוש מודים...",
                "mod_version": "גרסה",
                "mod_description": "תיאור",
                "no_description": "אין תיאור זמין",
                "mod_count": "{count} מודים מותקנים",
                # --- בדיקת עדכונים ---
                "update_available": "עדכון זמין",
                "update_available_msg": "גרסה {version} זמינה. לחץ להורדה.",
                "download_update": "הורד עדכון",
                "checking_updates": "בודק עדכונים...",
                "up_to_date": "הלאנצ'ר מעודכן",
                # --- ערכות נושא ---
                "theme": "ערכת נושא",
                "dark_mode": "מצב כהה",
                "light_mode": "מצב בהיר",
                "accent_color": "צבע עיקרי",
                # --- איפוס ---
                "reset_settings": "אפס הגדרות",
                "reset_everything": "אפס הכל",
                "reset_settings_confirm": "אפס את כל ההגדרות לברירת מחדל? החשבונות וקבצי המשחק יישמרו.",
                "reset_everything_confirm": "אזהרה: פעולה זו תמחק את כל קבצי המשחק, המודים, ההגדרות והקונפיגורציות. לא ניתן לבטל. האם אתה בטוח?",
                "reset_settings_done": "ההגדרות אופסו לברירת מחדל",
                "reset_everything_done": "הכל אופס בהצלחה",
                "confirm": "אשר",
                "cancel": "ביטול",
                # --- סנכרון קבצים ---
                "syncing_extras": "מסנכרן קבצי קונפיגורציה ומשאבים...",
                "extras_synced": "קבצי קונפיגורציה ומשאבים סונכרנו",
                "extras_sync_failed": "סנכרון חלק מהקבצים נכשל",
                # --- התקדמות הורדת מודים ---
                "downloading_mod": "מוריד: {name} ({current}/{total})",
                # --- צילומי מסך ---
                "nav_screenshots": "צילומי מסך",
                "screenshots_title": "גלריית צילומי מסך",
                "screenshots_desc": "צפה ונהל צילומי מסך של המשחק",
                "no_screenshots": "לא נמצאו צילומי מסך",
                "view_screenshot": "צפה",
                "delete_screenshot": "מחק",
                "screenshot_deleted": "צילום המסך נמחק",
                "open_screenshots_folder": "פתח תיקיית צילומי מסך",
                # --- צבעי ערכת נושא ---
                "color_blue": "כחול",
                "color_green": "ירוק",
                "color_orange": "כתום",
                "color_purple": "סגול",
                "color_red": "אדום",
            }
        }

    def set_language(self, lang_code: str):
        if lang_code in self.translations:
            self.lang_code = lang_code
            logger.info(f"[DEBUG LANG] Language changed to: '{self.lang_code}'")

    def get(self, key: str, **kwargs) -> str:
        lang_dict = self.translations.get(self.lang_code, self.translations["en"])
        template = lang_dict.get(key, self.translations["en"].get(key, f"[{key}]"))
        if kwargs:
            try:
                return template.format(**kwargs)
            except Exception:
                return template
        return template

    def is_rtl(self) -> bool:
        return self.lang_code == "he"